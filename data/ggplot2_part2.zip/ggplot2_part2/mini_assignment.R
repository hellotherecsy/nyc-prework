# Slide 23: Examine GGPlot objects
# Mini Assignment

# What kind of object is "g" this stored as?

# What are it's classes?

# Manipulate the "g" object directly to:
#  -- Capitalize the axis labels
#  -- Drop records in $data that are more than $2000 
#  -- Sample from this data set of sub-2k diamonds, keeping a random set of 5,000 diamonds.

##########################################
# Mini assignment:

# Use help and the internet as a resource to reproject the map data using three 
# different systems. Be sure one of the projection systems is Albers, which 
# is commonly used for US maps.

##########################################
# Mini Assignment: go to the color brewer page, find a new pallate for texas 
# that you like, and add the colors manually.

##########################################
# Mini Assignment: Slide 55: make it a gray scale (what's the red county?)

##########################################





