# Week 5 Instructor Notes

setwd("~/Desktop/desktop misc/desktop/RDA_with_notes/")


library(ggplot2)
#library(sp)
#library(leaflet)


# Slide 6
texas = read.csv("data/texas.csv")
head(texas)


# SLide 7
# Set the Base
g <- ggplot(data = texas, aes(x = long, y = lat))

# What is this if you had to guess?
g + geom_point()

# Slide 8
g + geom_polygon(aes(group = group))

#******************************************************************************#
# Exercise 1: Find the Texas capital building coordinates (x/y) and add it to the  
# map as a large red asterisk 

ga <- g + geom_polygon(aes(group = group))



# Find points:
# https://www.google.com/maps/place/Texas+Capitol/@30.274679,-97.7425392,17z/data=!4m8!1m2!2m1!1stexas+state+house!3m4!1s0x8644b5a014ac8dcf:0xcb6f5722a795d039!8m2!3d30.2746652!4d-97.7403505

# Build frame
austin=data.frame(long=-97.7425392, lat=30.274679)
austin_label=data.frame(long=-97.7425392, lat=30.45)

ga + geom_point(data=austin, color="Red", size=8, shape="*") + 
  geom_text(data=austin_label, aes(label="Austin"), colour="red") 


#******************************************************************************#

# Slide 10
# What is happening here?
texas2 = texas[sample(nrow(texas)), ]  # Row order matters!
ggplot(data = texas2, aes(x = long, y = lat)) + geom_polygon(aes(group = group))


# Slide 11
# install.packages("maps")
# help(package = "maps")
library(maps)
counties = map_data("county") # Using the built-in USA county
# map dataset.
ggplot(data = counties, aes(x = long, y = lat)) +
	geom_polygon(aes(group = group, fill = group)) +
  coord_map() # better to fix the proportions

# Slide 14
tx <- g + geom_polygon(aes(group = group, fill = bin))

# SLide 15-21: building a texas choropleth
tx2 <- tx + ggtitle("Population of Texas Counties")

# Slide 23: Examine GGPlot objects

g <- ggplot(data = diamonds, aes(x = carat, y = price)) +
	geom_point()
str(g)


#******************************************************************************#
# Mini Assignment

# What kind of object is "g" this stored as?

# What are it's classes?

# Manipulate the "g" object directly to:
#  -- Capitalize the axis labels
#  -- Drop records in $data that are more than $2000 
#  -- Sample from this data set of sub-2k diamonds, keeping a random set of 5,000 diamonds.





# Answers

g$labels$x <- "Carat"
g$labels$y <- "Price ($)"


data  <- g$data
data1 <- data[data$price < 2000, ]
data2 <- data1[sample(nrow(data1), 5e3), ]

g$data <- data2


str(g)
g
#******************************************************************************#

# Slide 27

g <- ggplot(data = diamonds, aes(x = carat, y = price)) +
	geom_point()

g$coordinates

# Slide 29

g2 <- g + coord_polar()

# Now compare

g$coordinates
g2$coordinates

g

# How to interpret this?
g + coord_polar()

# Slide 31

g + coord_flip()

g + coord_fixed(ratio =	1/7000)


# Slide 34: transforming coordinates

g + coord_trans(y = "log10", x = "log10")

ggplot(diamonds, aes(carat, price)) +
	geom_point() +
	geom_smooth(method = "lm") +
	scale_x_log10() +
	scale_y_log10() 



# Slide 36

g + coord_cartesian(ylim = c(0,5000), xlim = c(0, 1))

# Slide 37
tx 

tx + coord_map()

#******************************************************************************#

# Mini assignment:

# Use help and the internet as a resource to reproject the map data using three 
# different systems. Be sure one of the projection systems is Albers, which 
# is commonly used for US maps.









tx + coord_map(projection="lagrange")

tx + coord_map("bonne", lat0 = 50)

tx + coord_map("albers", lat0=39, lat1=45)

library(maps)
counties = map_data("county") # Using the built-in USA county
# map dataset.
ggplot(data = counties, aes(x = long, y = lat)) +
  geom_polygon(aes(group = group, fill = group)) +
  coord_map("albers", lat0=39, lat1=45) # better to fix the proportions

#******************************************************************************#




# Slide 39

d2 <- subset(diamonds, color == "D")
cc <- ggplot(data = d2, aes(x = color)) + 
	geom_bar(aes(fill = cut), position = "fill") +
  xlab("All D's")
cc

cc + coord_polar(theta = "y") + 
  theme(axis.title.y=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank()) + # Get rid of the "D" on the axis
  ggtitle("Grade D Diamonds: Cut and Frequency")

# Slide 44

ggplot(data = mpg, aes(x = displ, y = hwy)) +
	geom_point(aes(color = cty))
last_plot() +
	scale_color_gradient(low = "red", high = "yellow")

# Slide 46

ggplot(data = mpg, aes(x = displ, y = hwy)) +
	geom_point(aes(shape = fl))
last_plot() +
	scale_shape_manual(values = c(0, 15, 1, 16, 3))

# Slide 47: Shapes

r <- ggplot(data = mpg, aes(x = displ, y = cyl)) +
  geom_point(aes(color = drv, shape = fl))

# Specify the shapes manually
r + scale_shape_manual(values = c(0, 15, 1, 16, 3))

# Slide 51

#install.packages("RColorBrewer")
library(RColorBrewer)
display.brewer.all()

names(mpg)

# Slide 53
tx + scale_fill_brewer(
	palette = "OrRd")

# Slide 54
tx + scale_fill_manual(values = c("red", "orange", "yellow",
					  	  "green", "blue"))


# Mini Assignment: go to the color brewer page, find a new pallate for texas 
# that you like, and add the colors manually.



tx + scale_fill_manual(values = c('#feedde','#fdbe85','#fd8d3c','#e6550d','#a63603'))



# Mini Assignment: Slide 55: make it a gray scale (what's the red county?)

tx + scale_fill_grey()




# Slide 60: Themes and custom themes

tx + theme_grey()
tx + theme_bw()

# Slide 61
tx + theme(panel.border =
		   	element_rect(colour = "black",
		   				 fill = NA))

# install.packages("ggmap")
library(ggmap)
tx + ggmap::theme_nothing() # popular mapping theme

# What is this theme exacty?

ggmap::theme_nothing



# Slide 64

library(ggthemes)  # install.packages("ggthemes")
p <- ggplot(data = diamonds, aes(x = color)) + geom_bar(aes(fill = cut))

p + theme_excel() + scale_fill_excel()

p + theme_economist() + scale_fill_economist()

p + theme_few() + scale_fill_few()


p + theme_stata() + scale_fill_stata()


# Slide 76: Presentation Assignment (Don't look ahead please!)

# Slide 81

q <- ggplot(data = mpg, aes(x = displ, y = hwy)) +
	geom_point(aes(color = cty))
q

q + theme(legend.position =
		  	"bottom")

q + theme(legend.position = "bottom")



tx + scale_fill_brewer(palette = "Blues") +
  xlab("") +
  ylab("") +
  theme_bw() +
  coord_map(projection = "albers", lat0=39, lat1=45) +
  ggtitle("Population of Texas Counties")




q <- ggplot(data = mpg, aes(x =
                              displ, y = hwy)) +
  geom_point(aes(color = cty))
q

q + theme(legend.position = "none")

q + guides(color = "none")

theme_something <- function(base_size = 12, legend = FALSE){
  if (legend) {
    return(theme(axis.text = element_blank(), axis.title = element_blank(), 
                 panel.background = element_blank(), panel.grid.major = element_blank(), 
                 panel.grid.minor = element_blank(), axis.ticks.length = unit(0, 
                                                                              "cm"), panel.spacing = unit(0, "lines"), plot.margin = unit(c(0, 
                                                                                                                                           0, 0, 0), "lines"), complete = TRUE))
  }
  else {
    return(theme(line = element_blank(), rect = element_blank(), 
                 text = element_blank(), axis.ticks.length = unit(0, "cm"), legend.position = "none", panel.spacing = unit(0, 
                                                                                                                          "lines"), plot.margin = unit(c(0, 0, 0, 0), "lines"), 
                 complete = TRUE))
  }
}


tx + theme_something() # our new theme









# Slide 83
q + guides(color = "legend")
q + guides(color = "none")


# Side 97
p <- ggplot(data = iris, aes(x = Species, y = Sepal.Length)) +
	geom_violin(aes(fill = Species))

p

# Slide 98
p <- ggplot(iris, aes(x = Species, y = Sepal.Length)) +
	geom_violin(fill = 'gray', alpha = 0.5) +
	geom_dotplot(aes(fill = Species), binaxis = "y", stackdir = "center")

p

# Slide 101

p <- ggplot(mpg, aes(x = 1)) +
	geom_bar(aes(fill = class)) +
	coord_polar(theta = "y")
p

# Slide 103
set.seed(1)
dir <- cut_interval(runif(100,0,360), n=16)
mag <- cut_interval(rgamma(100,15), n=4)
sample = data.frame(dir=dir, mag=mag)
p <- ggplot(sample, aes(x=dir, fill=mag) ) +
	geom_bar() +
	coord_polar()

p

# Slide 105
install.packages("vcd")
library(vcd)
mosaic(Survived ~ Class + Sex, data=Titanic[1:3], shade=TRUE,
	   highlighting_fill=c('red4',"skyblue"), highlighting_direction="right")

# Let's change the order
str(Titanic)
class(Titanic)
Titanic
titan <- as.data.frame(Titanic, stringsAsFactors=FALSE)
titan <- titan[titan$Class!="Crew", ]
str(titan)
attributes(titan)

mosaic(Survived ~ Class + Sex, data=titan, shade=TRUE,
       highlighting_fill=c('red4',"skyblue"), highlighting_direction="right")


# Slide 107
# install.packages("treemap")
library(treemap)
data = read.csv('data/apple.csv', TRUE)

treemap(data,
		index=c("item", "subitem"),
		vSize="time1206",
		vColor="time1106",
		type="comp",
		title='Apple Corp. Financial Statements',
		palette='RdBu')


# Slide 112
# install.packages("car")
library(car)
scatterplotMatrix(mpg[ ,c(3,8,9)],
				  diagonal='histogram',
				  ellipse=TRUE)

# Slide 114

# install.packages("corrplot")
library(corrplot)
corrplot(cor(mtcars), order="hclust")

class( economics[440:470,'psavert'] ) 
View( economics[440:470,'psavert'] ) 

as.numeric( mean( as.vector(economics[440:470,'psavert'])), na.rm=TRUE )

?economics
fillcolor <- ifelse( economics[440:470,'psavert'] > as.numeric(mean( economics[440:470,'psavert'], na.rm=TRUE )) , 'steelblue', 'red4')

p <- ggplot(economics[440:470,], aes(x=date, y=psavert) ) +
	geom_bar(stat='identity', fill=fillcolor)
p



# Slide 119

p <- ggplot(economics[300:470,], aes(x=date, ymax=psavert, ymin=0) ) + geom_linerange(color='grey20', size=0.5) + geom_point(aes(y=psavert), color='red4') +
	theme_bw()
p


# Slide 121

fill.color <- ifelse(economics$date > '1980-01-01' & economics$date < '1990-01-01',
					 'steelblue', 'red4')
p <- ggplot(economics, aes(x=date, ymax=psavert, ymin=0) ) +
	geom_linerange(color=fill.color, size=0.9) +
	geom_text(aes(x=as.Date("1985-01-01",'%Y-%m-%d'), y=13), label="1980s") +
	theme_bw() 
p


# Slide 123
install.packages("openair")
library(openair)
data(mydata)
calendarPlot(mydata, pollutant = "o3", year = 2003)




# Slide 131


# Now need the github version of ggmap
devtools::install_github("dkahle/ggmap")
library(ggmap)
library(XML)
webpage <- "http://data.earthquake.cn/datashare/globeEarthquake_csn.html" 
tables <- readHTMLTable(webpage, stringsAsFactors=FALSE)
raw <- tables[[6]]
data <- raw[ ,c(1,3,4)]
names(data) <- c('date', 'lat', 'lon')
data$lat <- as.numeric(data$lat)
data$lon <- as.numeric(data$lon)
data$date <- as.Date(data$date, "%Y-%m-%d")

quakemap <- 
  ggmap(get_googlemap(center='china', zoom=4, maptype='terrain'), extent='device') + 
  geom_point(data=data, aes(x=lon, y=lat), colour='red', alpha=0.7, na.rm=TRUE) + 
  theme(legend.position="none")

# Slide 134 (on Mac, only seems to load properly in Chrome)
# install.packages("googleVis"); install.packages("WDI");

library(googleVis)
library(WDI);
library(RJSONIO) 
suppressPackageStartupMessages(library(googleVis))
DF <- WDI(country=c("CN","RU","BR","ZA","IN",'DE','AU','CA','FR','IT',
					'JP','MX','GB','US','ID','AR','KR','SA','TR'), indicator=c("NY.GDP.MKTP.CD", 'SP.DYN.LE00.IN', 'EN.ATM.CO2E.KT'),
		  start=2000, end=2009)

gdp_map <- gvisMotionChart(DF, idvar="country", timevar="year",  xvar='EN.ATM.CO2E.KT', yvar='NY.GDP.MKTP.CD')
plot(gdp_map)




library(RJSONIO) 
suppressPackageStartupMessages(library(googleVis))
DF <- WDI(country=c("CN","RU","BR","ZA","IN",'DE','AU','CA','FR','IT',
                    'JP','MX','GB','US','ID','AR','KR','SA','TR'), indicator=c("NY.GDP.MKTP.CD", 'SP.DYN.LE00.IN', 'EN.ATM.CO2E.KT'),
          start=2000, end=2009)
gdp_map <- gvisMotionChart(DF, idvar="country", timevar="year",
                           xvar='EN.ATM.CO2E.KT', yvar='NY.GDP.MKTP.CD')
# Exercise: Get Starbucks data and add it to the Texas plot
# https://github.com/smach/NICAR15data/blob/master/starbucks.csv

# Drop non-Texas locations
# Drop the "Licensed" locations
# Make a "crude" measure of location size using features/services
# Plot the dots in a visually appealing way and vary the size based on your measure.
# Which location is probably the first one in Texas? Mark this one with a star.
# Make a zoomed-in plot of Austin Tx and it's surrounding Starbucks. Use ggplot and ggmap and make two maps.





sb <- read.csv(file="Week5/starbucks.csv", stringsAsFactors=FALSE)








# Results
sbt <- sb[sb$State=="TX" & sb$Ownership.Type=="Company Owned", ]

sbt$size <- 1
sbt$size <- ifelse(nchar(sbt$Features...Products) < 40, 1,
				   ifelse(nchar(sbt$Features...Products) <60, 2, 3))
				   
table(sbt$size)
austin=data.frame(long=-97.7425392, lat=30.274679)

# TL: 30.565149, -98.119936
# BL: 30.100357, -98.103295
# R: 30.318311, -97.481989

tx + geom_point(data = sbt, aes(x = Longitude, y = Latitude, color=size)) +
	scale_color_gradient(low =	"yellow", high = "red") +
	coord_cartesian(xlim = c(-98.1,-97.35), ylim = c(30.25, 31)) + 
	geom_point(data=austin, color="Red", size=5, shape="*")

ggmap(get_googlemap(center='Austin', zoom=8, maptype='terrain'),  extent='device') +
	 geom_point(data = sbt, aes(x = Longitude, y = Latitude), size=.1, color="red")


	geom_point(data=data, aes(x=lon, y=lat),
			   colour='red', alpha=0.7, na.rm=TRUE) + theme(legend.position="none")

	


range(sbt$Longitude)
	  	
	  	
sbt$Store.Number
# sb <- get_sb()
# coordinates(sb) = ~Longitude+Latitude
# proj4string(sb) <- "+proj=longlat +datum=WGS84"
# 
# # Overlay CXI points on the dio polygons: 
# coded <- over(texassp, sb)




library(RColorBrewer)
