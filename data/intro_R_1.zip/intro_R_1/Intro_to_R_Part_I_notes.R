


setwd("~/Desktop/desktop/RDA_with_notes")


#### Week 1 Slide Notes: ####
# Welcome to the R Data Science and Visualization Course, my name is Derek
# Darves and I'll be leading you through this online course. THis course will
# some basic concepts from statistics and programming, but this will not be
# a statistcs or general programming course. Instead, our primary focus will be
# on the R language itself: teaching you the basics of getting up and running,
# which we'll focus on in this first module, as well as the basic building blocks
# of the language that, when mastered, will allow you to apply this very 
# powerful statistcal tool to a wide array of data driven questions that arise 
# from your work or research.

# At the outset of this course I'd like to emphasize what may be an obvious
# statement: namely that data analysis with computers -- statistics with computers --
# is not a spectator sport. You can watch me an other folks on the internet
# plug code into an R console and, in my experience, learn very little --
# in much the same way that watching boxing on television is no substitute
# for actually stepping into the ring to practice. WHich is to say that I *highly*
# recommend students of this course to take every one of the many coding opportunities
# we provide to begin to develop your "R muscle memory".

# Typing the code yourself, pausing when you don't understand a concept, and resolving
# the many small but solvable problems you will encounter is in fact the heart
# of any learning exercise in this area. In this course we point you in directions
# that we have learned, through experience, are fruitful in the first steps of the
# R journey, but the moments in which you are typing code, reflecting, problem solving,
# are really the core moments of the learning experience. 


# Slide 2
# Ok, so with all of that said, here is an outline of today's material:

# Slide 1:4: Intro to R

# R is part of the GNU: 
# --> http://www.gnu.org/gnu/gnu-history.html

# "The word “free” in “free software” pertains to freedom, not price. You may or
# may not pay a price to get GNU software. Either way, once you have the
# software you have four specific freedoms in using it. The freedom to run the
# program as you wish; the freedom to copy the program and give it away to your
# friends and co-workers; the freedom to change the program as you wish, by
# having full access to source code; the freedom to distribute an improved
# version and thus help build the community. (If you redistribute GNU software,
# you may charge a fee for the physical act of transferring a copy, or you may
# give away copies.)"

# This "free" aspect of R is *very* importat; it's not something we'll mention
# a lot after the first day but it's a foundational feature of the lanaguage itself.
# And it's important because statistical software appears to benefit from openness 
# much like any other software, from kernels to compilers. 

# And so so if you begin to use R extensively
# I encourage you to to what you can to support the community, either by
# writing packages or helping to test others' packages, and reporting bugs.



# Slide 6-7
# Slide 6: What language is missing here? What's the difference?

# One has the tail winds of history behind them in using R, at least today.
# The same might also be true of Python.

# Slide 8
# Key features: one might also add the support of a company, RStudio, and
# its ability to professionally develop/maintain the code base for a very
# effective Data Analysis oriented IDE.




# Does everyone have a stackexchange account? (get one if not!!)


# Slide 10: What's an interpreted language? What is single threaded?

# Slide 14: do we all know who Hadley Wickham is?

# to this list I would add Hadley's new book:
#-->     http://r4ds.had.co.nz/index.html

# Slide 16: Verify that RStudio is installed.

# Slide 20: Demonstration of alt-highlighting and other features of editor

# Slide 27/28: Environment and scoping (we will repeat this again and again)

################################################
# Mini assignment: work in pairs to selectively highlight each part of this function,
# then describe to the class what each code chunk is doing. Fix the bug in the code.

myenv <- new.env()

# Function to standardize host OS name
get_os <- function(){
	sysinf <- Sys.info()
	if (!is.null(sysinf)){
		os <- sysinf['sysname']
		if (os == 'Darwin')
			os <- "osx"
	} else { ## mystery machine
		os <- .Platform$OS.type
		if (grepl("^darwin", R.version$os))
			os <- "osx"
		if (grepl("linux-gnu", R.version$os))
			os <- "linux"
	}
}

myenv$computeros <- get_os()
################################################



# Slide 31: I recommend using the command line to install packages 
# Save an object with your installed packages as a list


# Slide 35: I recommend using Rds files


################################################
# Slide 36: Mini Assignment: 

# 1) Find what directory you are in. 

# 2) setwd to the parent directory of where you saved the course data files

# 3) Print the contents of the data folder on you HD using R and your computer's system 
#    commend equivalent.

# 4) Make an object and then clear everything from memory (Note that this does not clear 
#    loaded libraries!)

################################################


# Slide 37

#basic arithmetic
1+1*3
#numerical and string vectors
c(0, 1, 1, 2, 3, 9)
c("Hello, World!", "I am an R user") 
1:6
c(1:6)


# Vector addition
c(1, 2, 3, 4) + c(3, 4, 5, 6) 

# What happens here?
c(1, 2, 3, 4) + c(1, 2) 

# What's wrong with this: 
c(1, 2, 3, 4) + c(4, 5, 6)

TRUE + TRUE
FALSE + FALSE

# Slide 38
c(1, 2, 3, 4) > c(1, 2, 1, 2) 

c(1, 2, 3, 4) <= c(1, 5)

# What's wrong with this: 
c(1, 2, 3, 4) <  c(4, 5, 6) 

# Why does this work: 
c(1, 2, 3, 4) < c(4, 5)

# Slide 39

# Get in the habit of using '<-'

x = c(1, 2, 3, 4)
x[2]; x[2:4] 
x[-4] # Combine this with a positive subset...
x[x > 2]
x > 2

table(x > 2)


# Slide 41: Don't truncate TRUE as T, and FALSE as F in shared/reused code. 

2 == 4


# What do you think this will evaluate to: TRUE * TRUE



# Slide 42
2==4
x %% 2

14.8 %/% 7.2
14.5  /  7.2

# Slide 44

city <- c('New York', 'San Francisco', 'Chicago', 'Houston', 'Los Angeles') 
age  <- c(23, 43, 51, 32, 60)
sex  <- c('F', 'M', 'F', 'F', 'M')
people <- data.frame(city, age, sex)
people

# Problem: 
city <- c('New York', 'San Francisco', 'Chicago', 'Houston', 'Los Angeles') 
age  <- c(23, 43, 51, 32, 60)
sex  <- c('F', 'M', 'F', 'F', 'M', 'F')
people <- data.frame(city, age, sex)
people


# Slide 45:

people$age > 30 # Conditioned samples extracted from column 
people$city[people$age > 30] # Conditioning across variables

people$city[people$age > 30 & people$sex=="F"] # Conditioning across variables


people$sex
people['sex']

# Slide 46
################################################
# Read this file in using read.table as suggested by slide notes.
################################################

inspections = read.csv('data/BrooklynInspectionResults.csv', header=TRUE) 

inspections[c(66, 70, 71, 72), -2]

head(inspections)
str(inspections)



# Note that this is an index starting at 1 and not the same as row names!!
row.names(inspections) <- as.numeric(row.names(inspections)) + 1e3
inspections[c(66, 70, 71, 72), -2]


# Slide 47
restaurants = inspections$DBA


class(inspections)
class(restaurants)

restaurant_set = unique(restaurants) 
length(restaurant_set)
inspections = inspections[inspections$CRITICAL.FLAG == "Critical", ]

head(unique( inspections$DBA))



class(people.list$tabular.data)


################################################
# Mini assignment: What is the most common violation code for those with the "critical" flag?
# What zip code has the most critical flags?
# What zip code has the fewest critical flags?
################################################

# Slide 48: I recommend using CSV or tab delimited as an interchange format, and readr as the package to read in this text data. 

#install.packages("openxlsx")
library(openxlsx)
excel_data = read.xlsx("data/excel.xlsx", sheet=1) #read first sheet
#install.packages("foreign")
library(foreign)
stata_data = read.dta("data/statafile.dta") 
spss_data = read.spss("data/spssfile.sav", to.data.frame=TRUE, trim_values=FALSE, use.value.labels=FALSE) 
sas_data = read.xport("data/sasfile.xpt")


# Slide 50
people.list = list(AgeOfIndividual=age, Location=city, Gender=sex) 
people.list

# Slide 51/2
people.list$tabular.data = people 
people.list$tabular.data

people.list[[length(people.list)]] # Assume list in last position

people.list[[4]]


class(people)
attributes(people)
typeof(people)
str(people)

# Slide 55

library(lattice)
xyplot(dist ~ speed, data=cars)

# Slide 57
model = lm(dist ~ speed, data=cars)

lm(cars$dist ~ cars$speed)

class(model)

summary(model)

summary.lm

summary.lm
summary.factor


summary(lm)

# ***Slide 59***: notice how packages implement versions of a function depending 
#    on object type, eg summary.lm and summary.data.frame

# Slide 60:
xyplot(dist ~ speed, data=cars, type = c("p","r"))

# Slide 62: Recreate every data structure in the previous examples. 

################################################
# Mini assignment:
# Build a vector, list, and data.frame of your favorite cuisine types.
# For data structures that allow mixed data, assign an integer score of 1:10
# to your selection, where 10 means you really like this cuisine. Ditto for
# your ability to cook this food independently.
################################################



# Slide 64
vector1 = seq(2, 10, by=2) 
vector2 = 1:10 + 2
vector3 = 1:(10 + 2)

1:12

# Slide 65: 
n = 100
w = pi/n

pi / 1:10

x = seq(from = 0, to = pi, length = n) 
rect = sin(x) * w
sum(rect)

# Slide 66

group1 = rep(1:3, times=c(8, 10, 9)) 
group2 = factor(group1) 
class(group2)

set.seed(0)


vec_logic = c(TRUE, TRUE, TRUE, FALSE)

"TRUE" + "TRUE" 

vec_logic = c("TRUE", "TRUE", "TRUE", FALSE)

class(vec_logic)

vec_char = c('A', 'B', 'C', 'D')
vec_num1 = runif(5)
vec_char2 = sample(c('A', 'B'), size=10, replace=TRUE) 


vec_num2 = numeric(10) 
#10-item zero vector 
vec_logic; vec_char2; vec_num2

# Slide 68

set.seed(0)
vector = rnorm(10)
vec_max = max(vector)

vec_min = min(vector)
vector_trimmed = vector[vector < vec_max & vector > vec_min] 
vec_mean = mean(vector_trimmed)
vec_mean


# Slide 69
vector = 1:12
dim(vector)
dim(my_matrix)
my_matrix = matrix(vector, nrow = 3, ncol = 4, byrow = TRUE) #Default.
my_matrix 
dim(vector) = c(4, 3) 
vector


# Slide 70
set.seed(0)
vector1 = vector2 = vector3 = rnorm(3)
my_matrix = cbind(vector1, vector2, vector3)
vector1 
my_matrix

# Slide 71

my_mat = matrix(1:9,3,3) 
my_mat



my_mat = matrix(1:9,3,3, byrow=TRUE) 
my_mat


# Slide 73

city = c('Seattle', 'Chicago', 'Boston', 'Houston') 
temp = c(78, 74, 50, 104)
data = data.frame(city, 1)


# Subset methods

data[ , 1] 
data[ , 'cit'] 
data$city
#--#
data['cit'] # Confusing (but works because DF is a type of "list"
data[[1]] # Equivalent to row/column indexing

# And note, too:
data$cit # This should really bother you!

?`[[`

# Slide 74
data = data.frame(city, temp, stringsAsFactors = F) 
data$city = factor(data$city)

ave = mean(data$temp) 
data[data$temp > ave, ]

data[c(TRUE,FALSE, FALSE, TRUE), ]


# Slide 75
data = data.frame(city, temp) 
summary(data)

dim(data)

# Slide 77
order(data$temp) 
data[order(data$temp), ] # What is this command doing, technically?
data[c(3,2,1,4),]


# Slide 78
temp = c(27, 29, 23, 14, NA) 
mean(temp)

mean(temp, na.rm = TRUE)


sum( c(27, 29, 23, 14)) / 4

temp = c(27, 29, 23, 14, "NA") 
class(temp)
mean(temp)

# Slide 80
sapply(iris[ ,1:4], function(x) sd(x)/mean(x))

##*******************************##
# Mini Assignment
# Recreate the values created by the above sapply command manually, one by one.
# Bonus round: make a loop which does all four at once.



class(with(iris, aggregate(Sepal.Length, by = list(Species), mean)))
class(tapply(X = iris$Sepal.Length, INDEX=list(iris$Species), FUN=mean))


sd(iris[[1]]) / mean(iris[[1]])
sd(iris[[2]]) / mean(iris[[2]])
sd(iris[[3]]) / mean(iris[[3]])
sd(iris[[4]]) / mean(iris[[4]])

# So what is s/lapply doing? 

seq_along(names(iris[, 1:4]))
x = length(names(iris[, 1:4]))

b <- c()
i = 1
while(i <= x) {
	a = sd(iris[[i]]) / mean(iris[[i]])
	b = c(b, a)
	i = i + 1
}

b
rbind(names(iris[, 1:4]), b) # Not recommended!!

# Notes on formats:

lapply(iris[ ,1:4], function(x) sd(x)/mean(x))

unlist(lapply(iris[ ,1:4], function(x) sd(x)/mean(x)))

sapply(iris[ ,1:4], function(x) sd(x)/mean(x))



# Slide 81 and following
mylist = as.list(iris[ ,1:4]) 
sapply(mylist, mean)


myfunc = function(x) { 
	ret = c(mean(x), sd(x)) 
	return(ret)
}


result = lapply(mylist, myfunc) 
result

# 84
result.matrix = t(as.data.frame(result)) 
colnames(result.matrix) = c("mean", "sd") 
result.matrix

# 85
set.seed(1)
vec = round(runif(12) * 100)
mat = matrix(vec, 3, 4)
apply(mat, 1, sum) # Applying across the rows.

apply(mat, 2, function(x) max(x)-min(x)) #Applying across the columns.


# Slide 86
tapply(X = iris$Sepal.Length, INDEX=list(iris$Species), FUN=mean)

# Slide 87
with(iris, aggregate(Sepal.Length, by = list(Species), mean))


# 90: Conditionals

num = 4
if (num %% 2 != 0) {
	cat(num, 'is odd') 
}

# 91

num = 4
if (num %% 2 != 0) {
	cat(num, 'is odd') 
	} else {
		cat(num, 'is even') 
	}

num = 1:6
ifelse(num %% 2 == 0, yes='even', no='odd')

cbind(num, ifelse(num %% 2 == 0, yes='even', no='odd'))

# 93: ifelse 

set.seed(0)
age = sample(0:100, 20, replace=TRUE) # Explain this
res = ifelse(age > 70, 'old', ifelse(age <= 30, 'young', 'mid')) 
res

#######################
# Mini Assignment:
# Copy Iris and add a variabble indicating if each value of sepal.length is 
# greater than the mean sepal.length for the data frame.

# Bonus: How could we do this by species' mean?
#######################


# Slide 94

age
age[1]

age_group = cut(age, breaks=c(0,30,70,100), labels=FALSE) #Returns integers.
age_group
switch(age_group[1], 'young', 'middle', 'old')

# Slide 95
age_type = 'middle' 
switch(age_type, 
	   young = age[age <= 30],
	   middle = age[age <= 70 & age > 30] , 
	   old = age[age > 70]
)

age


# Slide 96

campaign_data = read.csv('data/campaign_contributions.csv', header=TRUE) 
campaign_data = campaign_data[campaign_data$AMNT > 0, ] 
summary(campaign_data$AMNT)


# Slide 97

id = "BB" # Bloomberg.
size = "platinum"
data = campaign_data[campaign_data$CANDID == id,]


switch(
	size,
	"bronze"   = scales::percent(nrow(data[data$AMNT <= 50,]) / nrow(data)),
	"silver"   = scales::percent(nrow(data[data$AMNT <= 250 & data$AMNT > 50,]) / nrow(data)),
	"gold"     = scales::percent(nrow(data[data$AMNT <= 500 & data$AMNT > 250,]) / nrow(data)),
	"platinum" = scales::percent(nrow(data[data$AMNT > 500,]) / nrow(data))
)

#######################
# Mini Assignment
# 1) Descibe what the value calculated above means in plain english.
# 2) Extend the switch example by writing an ifelse statement that creates a
# new variable to classift every contribution above $0.
# 3) Estimate the proportion of contributions in each contribution catetory
# for the the top 3 donors in the dataset.
#######################


# Slide 98

sign_data = read.csv('data/TimesSquareSignage.csv', header=TRUE) 
obs = nrow(sign_data)
for (i in 1:obs) {
	if (is.na(sign_data$Width[i])) {
		cat('WARNING: Missing width for sign no.', i, '\n')
	} }



calc_area = function(r) 
  { area = pi*r^2 
  return(area)
}


# Slide 99
i=1
while (i <= obs) {
	if (is.na(sign_data$Width[i])) {
		cat('WARNING: Missing width for sign no.', i, '\n')
	}
	i=i+1 }

# See also: message

message("This is a message in R...") # obviously this evaluates to plain text in logs.

# Slide 100 - 105

i=1 
j=1 
repeat {
	if (is.na(sign_data$Width[i])) {
		cat('WARNING: Missing width for sign no.', i, '\n') 
		j=j+1
	}
	if (j > 5) {
		cat('WARNING: Encountered more than 5 missing values')
		break
	}
	i=i+1
	if (i > nrow(sign_data)) {
		break
	} }


################################################################################
## Functions in R

# Slide 106

findprime = function(x) {
	if (x %in% c(2, 3, 5, 7)) 
		return(TRUE)
	if (x %% 2 == 0 | x == 1) 
		return(FALSE) 
	xsqrt = round(sqrt(x))
	xseq = seq(from = 3, to = xsqrt, by = 2) 
	if (all(x %% xseq != 0)) return(TRUE) 
	else return(FALSE)
}


# Assignment: 
# 1) What is each line of code doing?
# 2) How could we make this function more efficient? 
# 3) What appears to break this script?

findprime(49979687)
findprime(353868013)

findprime(982451653)
findprime(982451654)
findprime(1e15)
findprime(1e16)

# Issue: http://stackoverflow.com/questions/8580717/modulus-warning-in-r-lehmann-primality-test


bases = c(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 
		 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199)



findprime1 = function(x) {
	if (x %in% bases) 
		return(TRUE)
	if (x %% 2 == 0 | x == 1) 
		return(FALSE) 
	xsqrt = round(sqrt(x))
	xseq = seq(from = 3, to = xsqrt, by = 2) 
	if (all(x %% xseq != 0)) return(TRUE) 
	else return(FALSE)
}


findprime1(982451653)

system.time({ sapply(1:1e4, findprime)
})

system.time({ sapply(1:1e4, findprime1)
})

# Slide 107

system.time({ x1 = c()
for (i in 1:1e4) {
	y = findprime(i) 
	x1[i] = y
} })


# Note the improved performance

system.time({
	x2 = logical(1e4) 
	for (i in 1:1e4) {
		y = findprime(i)
		x2[i] = y }
})

# And again:
system.time({ sapply(1:1e4, findprime) })


# Slide 110

i=2
x = 1:2
while (x[i] < 1e3) {
	x [i+1] = x[i-1] + x[i]
	i=i+1 }
x = x[-i] 
print(x)



# "Everything that exists is an object, everything that happens is a function"
#  --John Chambers


# Functions, general principles:
# Helpful   &     Strict

# Trade offs:
# Verbose         -->       Clever
# Specialised     -->       General
# Isolated        -->       Contextual

calc_area = function(r) { 
	area = pi*r^2 
	return(area) # <-- good practice to be explicit even when there's only one
} 

calc_area(4)

# Slide 113
DegreesToRadians = function(d) { 
	valueInRadians = d * pi / 180 
	return(valueInRadians)
} 

DegreesToRadians(145)


# Slide 114
ConeVolume = function(r, h) { 
	volume = pi * r^2 * (h / 3) 
	return(volume)
}

ConeVolume(2, 5)


# Add error checking

r <- h <- 5

length(c(r,h))

ConeVolume = function(r, h) { 
	if(!is.numeric(c(r,h))) stop("r and h must be numeric!")
	if(h < 0 |r < 0) stop("You must specify positive values for radius and height!")
	volume = pi * r^2 * (h / 3) 
	return(volume)
}

ConeVolume(2, 5)
ConeVolume(2, -3)
ConeVolume(2, "g")

# Slide 115

SDcalc = function(x, type='sample') { 
	n = length(x)
	mu = mean(x)
	if (type == 'sample') {
		stdev = sqrt(sum((x-mu)^2)/(n-1)) 
		}
	if (type == 'population') {
	stdev = sqrt(sum((x-mu)^2)/(n))
	}
return(stdev) 
}


SDcalc(1:10); SDcalc(1:10, type='population')

# Mini Assignment
# Working in pairs, build a data.frame or vector with 100 random values from a 
# uniform distribution. Calculate the mean and standard deviation "by hand" 
# using R as a calculator. Then compare the results from SDCalc and R's built in 
# function for the same.


# SLide 117

SDcalc = function(x, type = 'sample', ...) {
	stopifnot(is.numeric(x), length(x) > 0, type %in% c('sample', 'population')) 
	n = length(x)
	mu = mean(x, ...)
	if (type == 'sample') {
		stdev = sqrt(sum((x - mu) ^ 2, ...) / (n - 1))
	}
	if (type == 'population') {
		stdev = sqrt(sum((x - mu) ^ 2, ...) / (n))
	}
	return(stdev)
}

test = c(1:10, NA) 
SDcalc(test, type='sample')
SDcalc(test, type='sample', na.rm=TRUE)


# Slide 119
Fac1 = function(n) {
	if (n == 0) 
		return(1) 
	return(n * Fac1(n-1))
} 
Fac1(5)

factorial <- function (x) gamma(1 + x)

factorial(5:100)

system.time({ sapply(1:150, factorial) })
system.time({ sapply(1:150, Fac1) })



which_generation = function(birth_year) { 
	if (birth_year > 2000) {
	category = 'Gen Z'
} else if (birth_year > 1985) {
	category = 'Gen Y'
} else if (birth_year > 1965) {
	category = 'Gen X' } else {
		category = 'Baby Boomer' }
	return(category) }

which_generation(1978)

years <- c(1978, 1988, 1998, 2008)
which_generation = Vectorize(which_generation) 
which_generation(years)


# Slide 124
a <- c('NPR', 'New York Times', 'MSNBC')
b <- c('Wall Street Journal', 'NPR', 'Fox News')
'%int%' = function(x, y) { intersect(x, y)
}
a %int% b


# Slide 125
c = c('Salon', 'The Onion', 'NPR')
news_list = list(a, b, c) 
Reduce('%int%', news_list)

# Slide 127

FuncList <- list(base = function(x) mean(x), 
				 med = function(x) median(x),
				 manual = function(x) { 
				 	n <- length(x)
				 	x <- sort(x)[c(-1,-n)] 
				 	mean(x)
				 }) 
set.seed(1)
x <- sample(100, 10) 
FuncList$base(x)


for (f in FuncList) { print(f(x))
}



# Slide 128: Functional Programming Examples

SdMean = function(x, type='sample') { 
	stopifnot(is.numeric(x), length(x) > 0, type %in% c('sample', 'population')) 
	x = x[!is.na(x)]
	n = length(x)
	mu = mean(x)
	if (type == 'sample') n = n-1 
	stdev = sqrt(sum((x-mu)^2)/(n)) 
	return(stdev)
}

# Slide 131

SdFunc = function(x, func, type = 'sample') {
	stopifnot(
		is.function(func),
		is.numeric(x),
		length(x) > 0,
		type %in% c('sample', 'population')
	) 
	x = x[!is.na(x)]
	n = length(x)
	m = func(x)
	if (type == 'sample') n = n - 1 
	stdev = sqrt(sum((x - m) ^ 2) / (n)) 
	return(stdev)
}

set.seed(1)
x = sample(100, 30)
SdFunc(x, type='sample') #Note the error. Missing func
SdFunc(x, func=median, type='sample')
				   

# Slide 133


SdFunc = function(func, type) {
	stopifnot(is.function(func),
			  type %in% c('sample', 'population')) 
	function(x) {
	    stopifnot(is.numeric(x), length(x) > 0)
		x = x[!is.na(x)]
		n = length(x)
		m = func(x)
		if (type == 'sample')
			n = n - 1 
		stdev = sqrt(sum((x - m) ^ 2) / (n)) 
		return(stdev)
	}
}


SdMean = SdFunc(func=mean, type='sample') 
SdMedian = SdFunc(func=median, type='sample')
set.seed(1)
x = sample(100, 30) 
SdMean(x)
SdMedian(x)

# Why might we do this?

# Hadley (function factories: http://adv-r.had.co.nz/Functional-programming.html)

# (1) The different levels are more complex, with multiple arguments and complicated bodies.
# (2) Some work only needs to be done once, when the function is generated.
