################################################
# Mini assignment: work in pairs to selectively highlight each part of this function,
# then describe to the class what each code chunk is doing. Fix the bug in the code.

myenv <- new.env()

# Function to standardize host OS name
get_os <- function(){
  sysinf <- Sys.info()
  if (!is.null(sysinf)){
    os <- sysinf['sysname']
    if (os == 'Darwin')
      os <- "osx"
  } else { ## mystery machine
    os <- .Platform$OS.type
    if (grepl("^darwin", R.version$os))
      os <- "osx"
    if (grepl("linux-gnu", R.version$os))
      os <- "linux"
  }
}

myenv$computeros <- get_os()
################################################

# Slide 36: Mini Assignment: 

# 1) Find what directory you are in. 

# 2) setwd to the parent directory of where you saved the course data files

# 3) Print the contents of the data folder on you HD using R and your computer's system 
#    commend equivalent.

# 4) Make an object and then clear everything from memory (Note that this does not clear 
#    loaded libraries!)
################################################

inspections = read.csv('data/BrooklynInspectionResults.csv', header=TRUE) 

# Mini assignment: What is the most common violation code for those with the "critical" flag?
# What zip code has the most critical flags?
# What zip code has the fewest critical flags?
################################################

# Mini assignment:
# Build a vector, list, and data.frame of your favorite cuisine types.
# For data structures that allow mixed data, assign an integer score of 1:10
# to your selection, where 10 means you really like this cuisine. Ditto for
# your ability to cook this food independently.
################################################

sapply(iris[ ,1:4], function(x) sd(x)/mean(x))

# Mini Assignment
# Recreate the values created by the above sapply command manually, one by one.
# Bonus round: make a loop which does all four at once.
################################################

# Mini Assignment:
# Copy Iris and add a variabble indicating if each value of sepal.length is 
# greater than the mean sepal.length for the data frame.

# Bonus: How could we do this by species' mean?
################################################
# Mini Assignment

campaign_data = read.csv('data/campaign_contributions.csv', header=TRUE) 
campaign_data = campaign_data[campaign_data$AMNT > 0, ] 
id = "BB" # Bloomberg.
size = "platinum"
data = campaign_data[campaign_data$CANDID == id,]


switch(
  size,
  "bronze"   = scales::percent(nrow(data[data$AMNT <= 50,]) / nrow(data)),
  "silver"   = scales::percent(nrow(data[data$AMNT <= 250 & data$AMNT > 50,]) / nrow(data)),
  "gold"     = scales::percent(nrow(data[data$AMNT <= 500 & data$AMNT > 250,]) / nrow(data)),
  "platinum" = scales::percent(nrow(data[data$AMNT > 500,]) / nrow(data))
)

# 1) Descibe what the value calculated above means in plain english.
# 2) Extend the switch example by writing an ifelse statement that creates a
# new variable to classift every contribution above $0.
# 3) Estimate the proportion of contributions in each contribution catetory
# for the the top 3 donors in the dataset.

################################################
# Mini Assignment

# Working in pairs, build a data.frame or vector with 100 random values from a 
# uniform distribution. Calculate the mean and standard deviation "by hand" 
# using R as a calculator. Then compare the results from SDCalc and R's built in 
# function for the same.
################################################
