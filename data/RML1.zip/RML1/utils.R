
install.packages('jpeg')
library(jpeg)
install.packages('readJPEG')


plot_jpeg = function(pathOrObject, add=FALSE, load = FALSE, loc = NULL, report = FALSE)
{
  require('jpeg')
  if(load){
    jpg = readJPEG(pathOrObject, native=T) # read the file
  } else {
    jpg = pathOrObject
  }
  res = dim(jpg)[1:2] # get the resolution
  if (!add) # initialize an empty plot area if add==FALSE
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n')
  if(is.null(loc)){
    rasterImage(jpg,1,1,res[1],res[2])
  } else {
    rasterImage(jpg,loc[1],loc[2],loc[3],loc[4])
  }
  if(report) return(res)
}
