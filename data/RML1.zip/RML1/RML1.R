
# Central Limit Theorem
# Sums  of independent random variables are normally distributed
# Means of independent random variables are normally distributed

MakeSamplingDist = function(nu = 1, n = 10000){
  U = runif(n=n*nu)
  U = matrix(U,nu,n)
  return(colSums(U)/nu)
}

hist(MakeSamplingDist(nu = 1))
hist(MakeSamplingDist(nu = 10))
hist(MakeSamplingDist(nu = 100))
hist(MakeSamplingDist(nu = 1000))


# Normal Dist
# Confidence Interval for Sample Mean
# Population Variance sigma^2 is Known

n = 50
sigma = 40
m = 300
plot_jpeg('Vxbar.jpg',load = TRUE)
se = sigma/sqrt(n)

alpha = .05
mu0 = 320
I = c(alpha/2, 1-alpha/2) 
q = qnorm(I, mean=m, sd=se)

# Display
set.seed(0)
normsims = rnorm(n = 100000, mean = m, sd = se)
plot(density(normsims))
abline(v = q[1], lwd = 2, lty = 2, col = "red")
abline(v = q[2], lwd = 2, lty = 2, col = "red")
abline(v = mu0, lwd = 2, lty = 2, col = "blue")



# R Functions for Normal Distributions

?dnorm # PDF
?pnorm # CDF
?qnorm # Value from probability
?rnorm # Simulate values

# pnorm
pnorm(-3:3)

# dnorm
n = 1000000
sum(dnorm((0:n)/n))/n

# qnorm 
qnorm(.5)

# rnorm
plot(density(qnorm(runif(1000000))))
plot(density(rnorm(1000000)))

# qqplot for Normal Distribution
qqnorm(rnorm(1000))
qqnorm(rnorm(1000)^2);qqline(rnorm(1000)^2)
qqnorm(runif(1000))
qqnorm((runif(1000)+runif(1000)))
qqnorm((runif(1000)+runif(1000)+runif(1000)))

# Central Limit Theorem Demonstration Function
# https://www.r-bloggers.com/sampling-distributions-and-central-limit-theorem-in-r/

SumarizeSamplingDistribution <- function(n,distribution=NULL,param1=NULL,param2=NULL) {
  r <- 10000
  my.samples <- switch(distribution,
                       "E" = matrix(rexp(n*r,param1),r),
                       "N" = matrix(rnorm(n*r,param1,param2),r),
                       "U" = matrix(runif(n*r,param1,param2),r),
                       "P" = matrix(rpois(n*r,param1),r),
                       "C" = matrix(rcauchy(n*r,param1,param2),r),
                       "B" = matrix(rbinom(n*r,param1,param2),r),
                       "G" = matrix(rgamma(n*r,param1,param2),r),
                       "X" = matrix(rchisq(n*r,param1),r),
                       "T" = matrix(rt(n*r,param1),r))
  all.sample.sums  <- apply(my.samples,1,sum)
  all.sample.means <- apply(my.samples,1,mean)   
  all.sample.vars  <- apply(my.samples,1,var) 
  par(mfrow=c(2,2))
  hist(my.samples[1,],col="gray",main="Distribution of One Sample")
  hist(all.sample.sums,col="gray",main="Sampling Distribution of the Sum")
  hist(all.sample.means,col="gray",main="Sampling Distribution of the Mean")
  hist(all.sample.vars,col="gray",main="Sampling Distribution of the Variance")
  par(mfrow=c(1,1))
}

# Central Limit Theorem Demonstration Function
# https://www.r-bloggers.com/sampling-distributions-and-central-limit-theorem-in-r/
source('~/Google Drive/DSA/R/CLT99.R')

SumarizeSamplingDistribution(10, distribution="E",1) #Exponential
SumarizeSamplingDistribution(50, distribution="E",1) #Exponential
SumarizeSamplingDistribution(100,distribution="E",1) #Exponential
SumarizeSamplingDistribution(10, distribution="X",14) #ChiSq
SumarizeSamplingDistribution(50, distribution="X",14) #ChiSq
SumarizeSamplingDistribution(100,distribution="X",14) #ChiSq
SumarizeSamplingDistribution(10, distribution="N",param1=20,param2=3) #Normal
SumarizeSamplingDistribution(50, distribution="N",param1=20,param2=3) #Normal
SumarizeSamplingDistribution(100,distribution="N",param1=20,param2=3) #Normal
SumarizeSamplingDistribution(10, distribution="G",param1=5,param2=5) #Gamma
SumarizeSamplingDistribution(50, distribution="G",param1=5,param2=5) #Gamma
SumarizeSamplingDistribution(100,distribution="G",param1=5,param2=5) #Gamma

## ChiSq Work

# Base Case
n = 100000
Z = rnorm(n=n,mean=0,sd=1)
chiSq_1 = Z^2
hist(chiSq_1,100,col = 'blue',ylim = c(0,n))

# Standardized Case 
plot_jpeg('standardizedNormals.jpg',load = TRUE, loc = c(-30,50,80,100))
mu = round(runif(1)*100)
sigma = round(runif(1*100))
n = 100000
Y = rnorm(n=n,mean=mu,sd=sigma)
Ybar = mean(Y)
Ystd = sd(Y)
chiSq_1 = ((Y-Ybar)/Ystd)^2
hist(chiSq_1,100)



# ChiSq Function
MakeChiSqDist = function(nu = 1, n = 10000){
  Z = rnorm(n=n*nu,mean=0,sd=1)
  Z = matrix(Z,nu,n)
  return(colSums(Z^2))
}

# ChiSq with different degrees of freedom
hist(MakeChiSqDist(2),100,main = 'ChiSq Distributions')
hist(MakeChiSqDist(5),100, add = T)
hist(MakeChiSqDist(10),100, add = T)

# ChiSq for high degrees of freedom approaches Normal Distribution
hist(MakeChiSqDist(100),100)
ChiSqDist = MakeChiSqDist(1000)
qqnorm(ChiSqDist)
qqline(ChiSqDist)




# ChiSq as Variance of Standard Normal

# V[X] = E[X^2] - (E[X])^2
# V[X] = E[X^2] when E[X] = 0

# ChiSq = Sum(E[Z^2]) where Z ~ N(0,1)
# ChiSq_n is the variance of the sum of n standard normal random variables

# You can visualize this as distance in 3 dimensional space
plot_jpeg('pythagoras3d.jpg',load = TRUE)



# ChiSq test for Variance

plot_jpeg('standardizedNormals.jpg',load = TRUE, loc = c(-30,120,80,150))
plot_jpeg('sd_CI.jpg',load = TRUE, loc = c(-170,100,310,500))

sigma0 = 30
S = 20
n = 50
alpha = .05

chiSqVarStat = qchisq(c(alpha/2,1-alpha/2), df = n-1)
chiObserved = (n-1) * S^2 / sigma0^2
chiSqVarStat
chiObserved

q = sort(sqrt(((n-1) * S^2) / chiSqVarStat)) 
titlestr = 'Chi Square Distribution of Variance'
plot(density(sqrt(((n-1) * S^2) / rchisq(n=1000000,df=n-1))), main = titlestr)
abline(v = q[1], lwd = 2, lty = 2, col = "red")
abline(v = q[2], lwd = 2, lty = 2, col = "red")
abline(v = sigma0, lwd = 2, lty = 2, col = "blue")



# ChiSq Test for Independence

plot_jpeg('chiSq_test.jpg',load = TRUE, loc = c(-100,200,164,366),report = T)

# Example: Attendance and Grades
quiz_data = matrix(c(44, 21, 12, 18), nrow = 2, ncol = 2, byrow = TRUE)
dimnames(quiz_data) = list(Attendance = c("Present", "Absent"), Grade = c("Pass", "Fail"))
chisq.test(quiz_data) 


## F and T distributions


# You can observe the ratio that you would expect between two random variances
# Each can have its own degrees of freedom

nu1 = round(runif(1)*100)
nu2 = round(runif(1)*100)
titlestr = paste0('nu1 = ', nu1, '\nnu2 = ', nu2)

par(mfrow=c(3,1))
hist(MakeChiSqDist(nu1)/nu1, main = paste0('nu = ', nu1))
hist(MakeChiSqDist(nu2)/nu2, main = paste0('nu = ', nu2))
hist((MakeChiSqDist(nu1)/nu1)/(MakeChiSqDist(nu2)/nu2),100, main = titlestr)
par(mfrow=c(1,1))

# Compare to F simulations
hist((MakeChiSqDist(nu1,n = 100000)/nu1)/(MakeChiSqDist(nu2,n = 100000)/nu2),100,main = titlestr)
hist(rf(100000,nu1,nu2),100,add = TRUE)



# t-Distribution from Z and ChiSq

plot_jpeg('t.jpg',load = TRUE, loc = c(-8,-40,611+5,516+30))

n = 100000
nu = round(runif(1)*100)
Zs = rnorm(n,mean = 0,sd = 1)
chiSqs = MakeChiSqDist(nu = nu, n = n)
t = Zs/(chiSqs/nu)

hist(t,100, col = 'red')
hist(rt(n=n,df = nu), 100, add = TRUE, col = 'blue')

plot_jpeg('t_F.jpg',load = TRUE, loc = c(20,50,166-50,132))



# t-Test
# Confidence Interval for Mean
# Population Variance sigma^2 is Unknown

set.seed(0)
normsims = rnorm(n = 100000, mean = 320, sd = 45)
plot(density(normsims))

mu0 = 315
n = 40

tstat = (mean(normsims) - mu0)/(sd(normsims)/(n-1))

alpha = .05
pt(q = tstat, df = n-1, lower.tail = FALSE) < alpha



set.seed(0)
n1 = 100
n2 =  80
SAT.Spring = rnorm(100, 1550, 200)
SAT.Fall   = rnorm(80, 1500, 210) 

titlestr = "Sample Distribution of SAT Scores"
plot(density(SAT.Spring), xlab = "SAT Score", main = titlestr, col = "red")
lines(density(SAT.Fall), col = "blue")
legend("topright", c("Spring", "Fall"), lwd = 1, col = c("red", "blue"), cex = 1)

boxplot(SAT.Spring, SAT.Fall, main = titlestr, col = c("red", "blue"), 
        names = c("Spring", "Fall"))

#Manually calculating the t-statistic.
t.statistic = (mean(SAT.Spring) - mean(SAT.Fall))/sqrt(var(SAT.Spring)/n1 + var(SAT.Fall)/n2)
t.statistic

t.test(SAT.Spring, SAT.Fall, alternative = "two.sided") 

# Observe the t.test function
methods(t.test)
getAnywhere(t.test.default)




#One-Way ANOVA

set.seed(0)
Low.Calorie = rnorm(200, 10, 1)
Low.Carb    = rnorm(200, 8.5, 1)
Low.Fat     = rnorm(200, 8, 1)
Control     = rnorm(200, 0, 1)

weight.loss = c(Low.Calorie, Low.Carb, Low.Fat, Control) 
Category = c(rep("Low Calorie", 200),
             rep("Low Carb", 200),
             rep("Low Fat", 200),
             rep("Control", 200))

boxplot(weight.loss ~ Category,
        col = c("red", "orange", "yellow", "green"),
        main = "Distribution of Weight Loss\nfor Various Diets")

summary(aov(weight.loss ~ Category))



# One-Way ANOVA
# Manual version

mean.loss = c(rep(mean(Low.Calorie), 200),
              rep(mean(Low.Carb), 200),
              rep(mean(Low.Fat), 200),
              rep(mean(Control), 200))

k = 4
n = length(weight.loss)
n_i = c(200,200,200,200)
ms.between = sum((weight.loss-mean.loss)^2)/(n-k)
groupmeans = colMeans(matrix(weight.loss,n/k,k))
ms.within  = sum( (groupmeans-mean(weight.loss))^2 * n_i )/(k-1)

ms.within/ms.between

summary(aov(weight.loss ~ Category))

