Please place these files in your working directory.
You can either open the individual R files in RStudio or you can the file called RML1.R.  That file, contains all the code in one place.
You will need to run utils.R in order to view the jpg images.