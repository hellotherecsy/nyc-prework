# Week 2 Instructor Notes:

rm(list=ls())

# Slide 5

data_sub = iris[iris$Species=='setosa', 3:5]
data_sub1 = subset(iris, Species=='setosa', 3:5) # But see the help notes!!
data_sub2 = with(iris, iris[Species=='setosa', 3:5]) 
head(data_sub, 1); head(data_sub1, 1); head(data_sub2, 1) # same-same-same


iris_tr1 = iris
iris_tr2 = iris
iris_tr2$v1 = (log(iris_tr2$Sepal.Length))


iris_tr3 <- transform(iris, v1=log(Sepal.Length))
# Scoping + Non-standard evaluation (NSE):

# R Core team notes:
?subset
# "...This is a convenience function intended for use interactively. For programming
# it is better to use the standard subsetting functions like [, and in particular 
# the non-standard evaluation of argument subset can have unanticipated consequences.

# DPLYR notes:
vignette("nse")
# "...However, while NSE is great for interactive use it’s hard to program with. 
# This vignette describes how you can opt out of NSE in dplyr, and instead 
# (with a little quoting) rely only on standard evaluation (SE)."

# A Simple Example

if(exists("a")) rm(a)
detach(scoped)
if(exists("scoped")) rm(scoped)

exam <- function(x){
	return(a * x)
}

exam(5)
a<-2
exam(5) # Where did it find this?

rm(a)
exam(5)
scoped <- new.env()
scoped$a <- 2
attach(scoped)

exam(5) # Why should this work?
a # <-- Because reasons...

detach(scoped)
rm(scoped)
exam(5)


# Slide 6:
iris_tr=iris

iris_tr = transform(iris, v1=log(Sepal.Length))

iris_tr$v2<- log(iris$Sepal.Length) # Build it within the data frame instead
head(iris_tr, 1)

# Helpful functions
all.equal(iris$v1, iris$v2) # Better equipped to deal with floating point rounding
identical(iris$v1, iris$v2) # Very strict, will often throw false positives with data.frame's

# Slide 7

groupvec = quantile(iris_tr$v1, c(0, 0.25, 0.50, 0.75, 1.0))
labels = c('A', 'B', 'C', 'D')
iris_tr$v3 = cut(iris_tr$v1, breaks=quantile(iris_tr$v1, c(0, 0.25, 0.50, 0.75, 1.0)), 
				 labels=labels, include.lowest=TRUE)


# Is there a problem with this new variable? (not on every computer)
iris_tr$v4 = cut(iris_tr$v2,
                 breaks=quantile(iris_tr$v2, c(0, 0.25, 0.50, 0.75, 1.0)),
                                 labels=c('A', 'B', 'C', 'D'),
				 include.lowest=TRUE)

print(iris_tr$v3[14], digits=20)
print(iris_tr$v2[14], digits=20)
round(quantile(iris_tr$v1, c(0, 0.25, 0.50, 0.75, 1.0))[1], digits=20)


# "... That R prints answers nicely is a blessing. And a curse. R is good enough at 
# hiding numerical error that it is easy to forget that it is there. Don’t forget.
# Whenever floating point operations are done — even simple ones -- you should assume
# that there will be numerical error. If by chance there is no error, regard 
# that as a happy accident — not your due. You can use the all.equal function 
# instead of == to test equality of floating point numbers.

# If you have a case where the numbers are logically integer but they have been 
# computed, then use round to make sure they really are integers.
# Do not confuse numerical error with an error. An error is when a computation 
# is wrongly performed. Numerical error is when there is visible noise resulting 
# from the finite representation of numbers. It is numerical error —- not an 
# error —- when one-third is represented as 33%."  -- Patrick Burns

# http://www.burns-stat.com/pages/Tutor/R_inferno.pdf

# And why does this happens? 

# "... Because internally computers use a format (binary floating-point) that cannot 
# accurately represent a number like 0.1, 0.2 or 0.3 at all. When the code is 
# compiled or interpreted, your “0.1” is already rounded to the nearest number 
# in that format, which results in a small rounding error even before the 
# calculation happens. Computers use binary numbers because they’re faster at 
# dealing with those, and because for most calculations, a tiny error in the 
# 17th decimal place doesn’t matter at all since the numbers you work with aren’t 
# round (or that precise) anyway." -- http://floating-point-gui.de/basic/



groupvec1 <- c(1.44, groupvec[[2]], groupvec[[3]], groupvec[[4]], groupvec[[5]])


iris_tr$v4 = cut(iris_tr$v1,
				 breaks=groupvec1, labels=c('A', 'B', 'C', 'D'),
				 include.lowest=TRUE, ordered_result=TRUE)



unique(c(.3, .4 - .1, .5 - .2, .6 - .3, .7 - .4)) # Why is this not 1?

print(c(.3, .4 - .1, .5 - .2, .6 - .3, .7 - .4), digits=15)

print(c(.3, .4 - .1, .5 - .2, .6 - .3, .7 - .4), digits=18)


all.equal(.3, .4 - .1)
identical(.3, .4 - .1)
identical(.2, .2)

###****###

# Slide 8
vec = rep(c(0,1), c(4,6))

vec_fac = factor(vec, labels=c('male', 'female', 'test'))

as.numeric(vec_fac)

# Slide 9: Add a level
vec1 = factor(rep(c(0,1,3), c(4,6,2)))

vec3 <-vec2 <- vec1

levels(vec2) = c("male", "female", "male")


levels(vec3) = c("male", "female", "bob", "male", "bob") # Throw away extra labels here

vec3 <-vec2 <- vec1

levels(vec3) = c("female", "bob", "male") # Right number of labels here


vec4 <- relevel(vec3, ref="bob") # Make Bob the stand against which all others are judged (the reference)


library(XML)


# Slide 12

data = iris[, 1:4] 

# How to do this automatically without the risky index selection?
# Like this:
data1 <- iris[ , sapply(iris, is.numeric)]

all.equal(data, data1)

data$id <- 1:nrow(data)

# Slide 15
data_l = stack(data) # A long dataset; treats all elements as pieces of data.
data_w = unstack(data_l)
all.equal(data, data_w) # Lost column order
data_w <- data_w[order(data_w$id), c(names(data))]
all.equal(data, data_w) # Lost column order


# Slide 16

subdata = iris[ , 4:5]
subdata[c(1,51, 101), ]

str(subdata)

# The presence of a factor triggers unstack to create three columns, one for each factor level:
levels(subdata$Species)
subdata_w = unstack(subdata)
head(subdata_w, 1)


# Slide 17: reshape2
library(reshape2) # Cast long format to wide (could also be called "aggregate" in this case)
dcast(data=subdata, # Specifying the data to manipulate
	  formula=Species ~ ., # Species should be the main column to "group" the set by. 
	  value.var='Petal.Width', #Values to fill in should come from Petal.Width. 
	  fun=mean) # Aggregate the values by the mean.

tapply(subdata$Petal.Width, INDEX=subdata$Species, mean) # Unpredictable output format but works

aggregate(subdata$Petal.Width, by=list(Species=subdata$Species), FUN=mean) # "Old School" style

aggregate(Petal.Width ~ Species, data = subdata, mean) # Better still, with formula notation


# Slide 19: going long
iris_long = melt(data=iris, id.vars ='Species')

set.seed(5)
i = sample(nrow(iris_long), 5) 
iris_long[i, ]


# Slide 20
dcast(data=iris_long, # Specifying the data to manipulate. 
	  formula=Species ~ variable, # Species is main col.; swing variable col. 
	  value.var = 'value', # Values to fill in should come from value col. 
	  fun=mean)


# Slide 21: Mini assignment: Tips dataset.

# WHat are the potential issues with this that need to be addressed in the data?


# Slide 22
library(reshape2)
test <- tips

dcast(tips, sex ~ size, value.var='tip', fun=mean)

# Slide 23 

dcast(tips, sex ~ . , value.var='total_bill', fun=mean)

# Build a standarized variable
test$proprt <- test$tip / test$total_bill

plot(test$proprt, test$size)

summary(lm(proprt ~ sex, data=test))
t.test(test$proprt~as.factor(test$sex))

# Log of proportion
summary(lm(log(proprt) ~ sex, data=test))
plot(lm(log(proprt) ~ sex, data=test))

# Slide 25
datax = data.frame(id=c(1,2,3), gender=c('M', 'F', 'M'))
datay = data.frame(id=c(3,1,2), name=c('tom','john','mary')) 
datax; datay

merge(datax, datay, by=intersect(names(datay), names(datax)), all.x = TRUE)

# Slide 27
iris_split = split(iris, iris$Species) 
class(iris_split)
head(iris_split) # What do we have in each element of the list?

# Slide 28
iris_unsplit = unsplit(iris_split, iris$Species)
class(iris_unsplit)


# Slide 30

tips
tips_by_sex = split(tips, tips$sex)
head(tips_by_sex[[1]], 2)

ratio_fun = function(x) { 
	sum(x$tip) / sum(x$total_bill)
}

# Slide 31
result = lapply(tips_by_sex, ratio_fun)
result

# Slide 34
fruit = 'apple orange grape banana'
split.string.list = strsplit(fruit, split=' ')
fruitvec = unlist(split.string.list)
length(fruitvec)

# Slide 36
paste(fruitvec, collapse = ' ')


# Slide 37
n = 1:20
xvar = paste('x', n, sep = '')
right = paste(xvar, collapse = ' + ') 
left = 'y ~'
my_formula = paste(left, right) 
my_formula

# Slide 39

gsub('a', '?', fruit)
gsub('a\\$', '?', fruit)
gsub('^a', '?', fruit)


gsub('an', 'HA', fruit)

# Slide 40

grep('grape', fruitvec)
grep('dsfsdf', fruit)

grepl('a', fruitvec)

grep('an', fruitvec)

# Extending regex
fruit
gsub("e ", "e's ", fruit)
gsub("e$", "e's", fruitvec)
gsub("^a", "A", fruitvec)


## capitalizing
gsub("(\\w)(\\w*)", "\\U\\1\\L\\2", fruit, perl=TRUE)
gsub("\\b(\\w)",    "\\U\\1",       fruit, perl=TRUE)

# Cap the word
gsub("(\\w)",    "\\U\\1",       fruitvec, perl=TRUE)


# Slide 42
#get packages table
#install.packages("XML")
library(XML)
web = 'http://cran.r-project.org/web/packages/available_packages_by_name.html' 
packages = readHTMLTable(web, stringsAsFactors = FALSE)

pnames = packages[[1]][ , 1]; length(pnames)

pnames = pnames[2:11]

# Slide 43
str(packages)


b = 'http://cran.r-project.org/web/packages/'
a = '/index.html'
urls = paste0(b, pnames, a)


# Slide 44: Test run with one record
table = readHTMLTable(urls[1], stringsAsFactors=FALSE, header=FALSE) 
info = table[[1]]
paste0(info$V1, info$V2)


# Slide 45: Build a list of 10 packages
tables = lapply(urls, readHTMLTable, stringsAsFactors=FALSE, header=FALSE) 
infos  = lapply(tables, function(x) x[[1]])
infovec = lapply(infos, function(x) paste0(x$V1, x$V2))

aname = lapply(infovec, function(x) x[grep('^Author:', x)]) 

grep('Author:', infovec[[1]])


anamevec = lapply(aname, function(x) substr(x, 8, nchar(x))) 
anamevec = unlist(anamevec)
name.df = data.frame(pnames, anamevec)

# Slide 50

date1 = '1989-05-04' 
class(date1)

date1 = class(as.Date(date1))
class(date2)

date2 = 'May 04, 1989'
date2 = as.Date(date2)




date2 = as.Date(date2, format='%B %d, %Y')

format(date2, '%B %d, %Y')
class(format(date2, '%B %d, %Y'))

as.POSIXct(date2)

Sys.time()

format(date2, '%B %d, %y')
class(format(date2, '%B %d, %y'))



# And what is this thing?
as.numeric

Sys.Date() - date2

as.numeric(as.Date("1970-01-01")) # Epoch (most of the time, but see Micro$oft)

date1 = '05/04/1989'
date1 = as.Date(date1, format='%m/%d/%Y')

# Formatting examples, useful for printing.
format(date1, "%B, %Y") 
format(date1, "%b, %Y") 
format(date1, "%b-%y") 
format(date1, "%b --everything by the percent and first character is arbitrary-- %Y") 

# Slide 51
date2 = date1 + 31 
date2 - date1 # Be weary of time diff objects!!



date2 = date1 - 31 
date3 = date1 - 600 
as.numeric(date2)
as.numeric(date3) # How can this be??

# Best to use numbers when caculating differences with a specific value in mind:

Sys.Date() - as.Date("1978-03-29") # <-- instead of this 

as.numeric(Sys.Date() - as.Date("1978-03-29"))/365.25 # <-- Do somethig like this

# Now calculate your own age and see if it works

# Slide 53

dates = seq(as.Date(date1), length=4, by='day') 
format(dates, '%w') # What does this mean about the weekday?
weekdays(dates)



# Mini assignment: build a sequence of dates from the first day of Feb 2016 to 
# yesterday, using the pattern above. Make your code flexible so it could work
# at different times





# Answer (well, one answer at least)
test <- function(x) {
	now <- Sys.Date()
	yesterday <- Sys.Date() - 1
	ref <- as.Date(paste(2016, "02", "01", sep="-"))
	return(seq(from = ref, to=yesterday, by='day'))
}

seq.	
seq(from=1, to=100, by=2)	
test()


# Slide 54

time1 = '1989-05-04'
time1 = as.POSIXct(time1)
time1l = as.POSIXlt('1989-05-04')

time1 = "2011-03-1 01:30:00"
time1 = as.POSIXct(time1, format="%Y-%m-%d %H:%M:%S") 
time1 = as.POSIXct("2011-03-1 01:30:00", tz='GMT')
as.POSIXlt(time1, tz="EST")

time2 = seq(from=time1, to=Sys.time(), by='month')


# Slide 55
time1 = ISOdatetime(2011,1,1,0,0,0)
set.seed(1); sample(x=1:30, 10)
rtimes = ISOdatetime(2013, rep(4:5,5), sample(x=1:30, 10), 0, 0, 0)



# Slide 56

#install.packages("xts")
library(xts)
x = 1:4
y = seq(as.Date('2001-01-01'), length=4, by='day') 
date1 = xts(x, y)
class(date1)

# Slide 57

value = coredata(date1) 
coredata(date1) = 2:5 
time = index(date1)

# Slide 58

x = 5:2
y = seq(as.Date('2001-01-02'), length=4, by='day') 
date2 = xts(x, y)
date3 = cbind(date1, date2)
names(date3) = c('v1', 'v2')
date4 = rbind(date1, date2)
names(date4) = 'value'

rbind.

# Aggregate example with xts object
class(date4)
d4 <- aggregate(date4, format(index(date4),"%d"), function(d) c(mean(d)))

aggregate.ts

# Aggregating by minutes
set.seed(21)
i <- Sys.time()+seq_len(60*24*30)*60
x <- xts(rnorm(length(i)),i)
# call aggregate.zoo
z <- aggregate(x, format(index(x),"%H:%M"), function(d) c(mean(d),sd(d)))


# Slide 59

window(date4, start=as.Date("2001-01-04"))


# SLide 61
#install.packages("quantmod")
library(quantmod)
options(getSymbols.auto.assign=FALSE)
library(xts)
SSEC = getSymbols('^SSEC', src='yahoo', from='2000-01-01') 
head(SSEC, 3)



# Slide 62

class(SSEC)
SSEC
SSEC$ratio = with(SSEC, diff(SSEC.Close)/SSEC.Close)

head(SSEC$ratio)

# WHat's this doing above? Let's look closelt at the object:
cbind(diff(SSEC$SSEC.Close)[1:5], SSEC$SSEC.Close[1:5])

data.df <- as.data.frame(SSEC) # easier to work with than an XTS object
row.names(data.df)
# Save date as variable
data.df$date <- as.Date(rownames(data.df))
row.names(data.df) <- NULL

data.df[order(abs(data.df$ratio), decreasing=TRUE), ][1:5, ]

# What's the above code doing? Read it from the inside out by highlighting each section


# Slide 63
# install.packages("lubridate")
library(lubridate)
data.df$mday <- as.numeric(month(data.df$date))

data.df$date <- as.Date(data.df$date)

# Base R solution:
as.numeric(format(data.df$date, '%m'))

res <- round(tapply(data.df$ratio, data.df$mday, mean, na.rm=TRUE), digits=4)

cat(format(res * 100, digits=2, scientific=F))

options(scipen=8)
res <- tapply(data.df$ratio, data.df$mday, mean, na.rm=TRUE)


# Slide 66

# install.packages(c("stringr","plyr"))
library(stringr)
library(plyr)
library(lubridate)

setwd("/Users/ddarves/Dropbox/nycda/RDA_with_notes/")
data <- read.table('data/qqdata.csv', header=TRUE, sep=',',
                  stringsAsFactors=FALSE) 
head(data, 3)


# SLide 67
time = as.POSIXct(data$time, tz='GMT') 
id = as.factor(data$id)
data1 = data.frame(id, time)
user = as.data.frame(table(data1$id))
user = user[order(user$Freq, decreasing=T), ] 
user[1:5, ] #getting the top five chat users

# Slide 68
data1$hour <- hour(data1$time)
hours      <- as.data.frame(table(data1$hour))
hours      <- hours[order(hours$Freq, decreasing=TRUE), ] 
data1$wday <- wday(data1$time)
wdays      <- as.data.frame(table(data1$wday))
wdays      <- wdays[order(wdays$Freq, decreasing=TRUE), ]

?wday
x <- as.Date("2016-10-30")
wday(x) #4
format(x, "%w") # Note the difference in Base R

# Slide 71
#install.packages(c("RSQLite","learningr"))
library(DBI)
library(RSQLite)
driver = dbDriver("SQLite")
db_file = system.file("extdata", "crabtag.sqlite", package="learningr") 
conn = dbConnect(driver, db_file)
query = "SELECT count(*) FROM Daylog"
id_block = dbGetQuery(conn, query)
(id_block = dbGetQuery(conn, query)) # Evaluate and print to stdout

# Print tables in connection:
dbListTables(conn)

# Print "str" for tables in connection
dbGetQuery(conn, "PRAGMA table_info(DeploymentNotebook);")
dbGetQuery(conn, "PRAGMA table_info(LifetimeNotebook);")
dbGetQuery(conn, "PRAGMA table_info(Daylog);")

# Always close the DB connection!
dbDisconnect(conn)

# Slide 75

# install.packages("RCurl")
# install.packages("RJSONIO")

library(RCurl)
library(RJSONIO)


mykey <- 'a98d04ac43156c84'
url   <- paste0('http://api.wunderground.com/api/',
             mykey, '/conditions/forecast/q/autoip.json') 

# Load this into a web broswer:
print(url)

finalurl <- url

# Slide 76

fromurl <- function(finalurl) {
  web = getURL(finalurl)
  raw = fromJSON(web)
  high = raw$forecast$simpleforecast$forecastday[[2]]$high['fahrenheit'] 
  low = raw$forecast$simpleforecast$forecastday[[2]]$low['fahrenheit'] 
  condition = raw$forecast$simpleforecast$forecastday[[2]]$conditions 
  currenttemp = raw$current_observation$temp_c
  currentweather = raw$current_observation$weather
  city = as.character(raw$current_observation$display_location['full']) 
  result = list(city=city, 
                current=paste(currenttemp, '°C ', currentweather, sep=''), 
                tomorrow=paste(low, '-', high,'°C ', condition, sep='')) 
  names(result) = c('city', 'current', 'tomorrow') 
  return(result)
}

x <- fromurl(url)

# Take this apart:

web = getURL(url)
raw = fromJSON(web)
str(raw)

# See: http://www.w3schools.com/js/js_json_intro.asp


# Slide 79

library(XML)
url = 'http://mirrors.ustc.edu.cn/CRAN/web/packages/available_packages_by_date.html' 
tables = readHTMLTable(url, stringsAsFactors=FALSE, header=TRUE)

# Check the source code of the URL stored in `url`

# http://www.w3schools.com/html/html_tables.asp

data = tables[[1]]
data[2,]
data[3, ]



res = nchar(data[,2])
hist(res, main="R Package Name Length", xlab="Length")


# Slide 81
url     <- "http://www.w3schools.com/xml/plant_catalog.xml" 
xmlfile <- xmlTreeParse(url) #download and parse XML 
xmltop  <- xmlRoot(xmlfile) #get root node 
xmlValue(xmltop[[10]][[1]]) #get leaf node data

xmlValue(xmltop[['PLANT']][['COMMON']]) #get data from children of 'xmltop'

# Slide 82
xmlSApply(xmltop[[1]], xmlValue, recursive=TRUE)

xmlSApply(xmltop, xmlValue)



plantcat = xmlSApply(xmltop, function(x) xmlSApply(x, xmlValue)) 

plantcat_df = data.frame(t(plantcat),row.names=NULL) # Note the 't'
plantcat_df[1:5,1:4]


t(1:5)
cbind(1:5, 5:1)
t(cbind(1:5, 5:1))


# Slide 83

library(RCurl)
library(XML)
url = 'http://www.imdb.com/title/tt0111161/criticreviews?ref_=tt_ov_rt' 
raw = getURL(url)
data = htmlParse(raw)
xpath = '//tr[@itemprop="reviews"]/td[2]/div' # http://www.w3schools.com/xml/xml_xpath.asp
nodes = getNodeSet(data, xpath)
text = sapply(nodes, xmlValue)



# Get the ratings from your own favorite movie

url = 'http://www.imdb.com/title/tt0151804/criticreviews?ref_=tt_ov_rt' 
raw = getURL(url)
data = htmlParse(raw)
xpath = '//span[@itemprop="ratingValue"]'
nodes = getNodeSet(data, xpath)
sapply(nodes, xmlValue)

?getNodeSet


