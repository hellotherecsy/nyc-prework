######################################
# Slide 21: Mini assignment: Tips dataset.

# WHat are the potential issues with this that need to be addressed in the data?

######################################
# Slide 53

# Mini assignment: build a sequence of dates from the first day of Feb 2016 to 
# yesterday, using the pattern above. Make your code flexible so it could work
# at different times

######################################
library(devtools)
install_github("DerekYves/tindex")
library(tindex)

# Assignment: 
# (1) Build a dataframe from mtcars
# (2) Keep MPG, cyl, and model name.
# (3) Build a new id variable that corresponds to the manufacturer of the vehicle
# (4) Sort by mpg, ascending
# (5) Reshape the dataset wide by automaker

# AMC, Hornet, Chrysller, Dodge Challenger, Valiant, Phlymoth

ts <- mtcars

ts$group <-  as.factor(gsub("([[:alpha:]]+).*", "\\1", rownames(ts)))

gsub("([[:alpha:]]+).*", "\\3", "Toyota Corona")

group <- strsplit(rownames(ts), split=" ")
ts$group1 <- unlist(lapply(group, function(x) x[[1]]))

ts$index <- tindex(ts, group, output="index")

ts$final <- with(ts, ave(rep(1, nrow(ts)), group, FUN = seq_along))

ts <- ts[ , c('group', 'mpg', 'index')]

reshape(ts, idvar="group", timevar="index", direction="wide")

