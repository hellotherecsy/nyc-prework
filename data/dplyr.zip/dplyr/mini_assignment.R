#############################################
#  Slide 10: 
# Mini Assignment: Diagnose this problem by examining the data
vivian <- bnames[bnames$name == "Vivian", ] 

# Problem plot
qplot(year, prop, data = vivian, geom = "line")

qplot(year, prop, data = vivian[vivian$sex=="girl",], geom = "line")

qplot(year, prop, data = vivian, geom = "point")
qplot(year, prop, data = vivian, geom = "line", color = sex)

#############################################
# Slide 30/1
# Mini Assignment -- do this in base R and dplyr: 

# **Find all of the names that are in the same soundex as the name “Vivian”. 
# **Find all of the girls (subset) born in 1900 or 2000.
# How many times did a name reach a prop greater than 0.01 after the year 2000?

#############################################
# Compound select statements
select(mtcars, starts_with(c("m")), starts_with("c"))

# Regex:
select(mtcars, matches("^c|^m"))

# MINI ASSIGNMENT: Slide 40: Perform this in base R as well.

#############################################
# Slide 59: Mini Assignment #1 

# With th the vivian data frame:
# a. Add a new column to the data that changes the prop to a percentage.
# b. Create a summary that displays the min, mean, and max prop Vivian’s name.

# Mini assignment 2: in pairs, describe the two approaches below in plain english 
# and venture a guess about what the output represents.
# (hint: for method 1 work inside-out, as you would with SQL).

# Method 1: SQL-ish
# install.packages("nycflights13")
library(nycflights13)

flights$date <- as.Date(x=paste(flights$year, flights$month, flights$day, sep="-"))

hourly_delay <- filter( 
  summarise(
    group_by( # Groups the operation by a particular (factor-like) variable
      filter(
        flights, 
        !is.na(dep_delay)
      ), 
      date, hour
    ), 
    delay = mean(dep_delay), 
    n = n()
  ), 
  n > 10 
) 


# Method 2: magrittr-ish
hourly_delay2 <- flights %>% 
  filter(!is.na(dep_delay)) %>% 
  group_by(date, hour) %>% 
  summarise( 
    delay = mean(dep_delay), 
    n = n() ) %>% 
  filter(n > 10)

# What could we add to the output above?

class(hourly_delay2)

group_by(ungroup(hourly_delay2), date) %>%
  summarize(., `Average Delay`= paste0(round(mean(delay), digits=1), "hours")) %>%
  arrange(., desc(mean)) %>%
  slice(., 1:10)

#############################################

