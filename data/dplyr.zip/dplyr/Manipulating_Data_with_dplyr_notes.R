# DPLYR Section

library(ggplot2)
library(dplyr)

# Slide 5
setwd("/Users/ddarves/Dropbox/nycda/RDA_with_notes")
setwd("~/Desktop/desktop misc/desktop/RDA_with_notes/")

bnames = read.csv("data/bnames.csv.bz2", stringsAsFactors = FALSE) 
births = read.csv("data/births.csv", stringsAsFactors = FALSE)

# We will explore ggplot2 more in the following week, but let's visualize the 
# data with "quick plot [qplot]", the convenience wrapper for ggplot2.

# Assignment: select a name of interest to you and plot it: 
derek <- bnames[bnames$name == "Derek", ]
qplot(year, prop, data = derek, geom = "line")
qplot(year, prop, data = derek)


#  Slide 10: 
# Mini Assignment: Diagnose this problem by examining the data
vivian <- bnames[bnames$name == "Vivian", ] 

# Problem plot
qplot(year, prop, data = vivian, geom = "line")

qplot(year, prop, data = vivian[vivian$sex=="girl",], geom = "line")

qplot(year, prop, data = vivian, geom = "point")
qplot(year, prop, data = vivian, geom = "line", color = sex)



# Slide 13

michaels = bnames[bnames$name == "Michael" | bnames$name == "Michelle", ]
qplot(year, prop, data = michaels, geom = "line", color = interaction(sex, name))

# Only Johnny Cast, poor guy
sues = bnames[bnames$name == "Sue", ]
qplot(year, prop, data = sues, geom = "line", color = sex)


# Slide 17

# dplyr provides a flexible grammar of data manipulation. 
# It's the next iteration of plyr, focused on tools for working with data frames 
# (hence the d in the name).
# 
# Details
# 
# It has three main goals:
# 
# Identify the most important data manipulation verbs and make them easy to use from R.
# Provide blazing fast performance for in-memory data by writing key pieces in C++ (using Rcpp)
# Use the same interface to work with data no matter where it's stored, whether in a data frame, 
# a data table or database.

# To learn more about dplyr, start with the vignettes: browseVignettes(package = "dplyr")



# Restart R to illustrate a problem:

library(dplyr)

tbl_df(mtcars)
names(mtcars)

library(plyr)

desc()
library(dplyr)

# There is a lot of legacy code out there in major packages (ACS) that use plyr.
# This can be a source of much frustration, further illustrating why you should
# always fully specify your function calls in code with a package reference, e.g:
# dplyr::arange
# dplyr::group_by


df = data.frame(
  color = c("blue", "black", "blue", "blue", "black"), value = 1:5)
tbl = tbl_df(df)


data.frame( tbl[tbl$color=="blue", ]
            )




# Most dplyr functions have an SE equivalent:
arrange(iris, Sepal.Width)
arrange_(iris, "Sepal.Width") # <-- Use this for code writing


# Slide 22 : it just shows the first 10 rows, period.
library(ggplot2) # for diamonds
library(tibble)
tbl_df(diamonds)
tibble(table(diamonds$cut))

# Tibbles and Tbl_df's

# Things seem to be moving toward tibble's in hadleyverse

# tbl_df
# The S3 class tbl_df wraps a local data frame. The main advantage to using a 
# tbl_df over a regular data frame is the printing: tbl objects only print a few 
# rows and all the columns that fit on one screen, describing the rest of it as text.

# tibble

# tibble is a trimmed down version of data.frame that:
# * Never coerces inputs (i.e. strings stay as strings!).
# * Never adds row.names.
# * Never munges column names.
# * Only recycles length 1 inputs.
# * Evaluates its arguments lazily and in order.
# * Adds tbl_df class to output.
# * Automatically adds column names.

a <- 1:5
tibble(a, b = a * 2)
tibble(a, b = a * 2, c = 1)
tibble(x = runif(10), y = x * 2)


a <- 1:5000
tibble(a, b = a * 2)
tibble(a, b = a * 2, c = 1)
tibble(x = runif(5000), y = x * 2)

tibl <- as_tibble(iris)
class(tibl)

tblf <- tbl_df(iris)
class(tblf)
?tbl_df

# Example of difference with data.frame:
tibble(color = c("blue", "black", "blue", "blue", "black"), value = 1:5)

tibble(color = c("blue", "black", "blue", "blue", "black", "black"), value = 1:2)

# Why does this work?
data.frame(color = c("blue", "black", "blue", "blue", "black", "black"), value = 1:2)


# Slide 23-25: Discussion of dplyr

# Be sure to see the dplyr vignette using the builtin nycflights data:
library(dplyr)
vignette("introduction")
# install.packages("nycflights13")
library(nycflights13)


# Slide 26:
df = data.frame(
  color = c("blue", "black", "blue", "blue", "black"), value = 1:5)
tbl = tbl_df(df)

filter(tbl, color == "blue")
class(df)

# 29: Filter example
filter(df, value %in% c(1, 4))

# Question: what is %in% called again (review). What is this doing above?


# Slide 30-38, examples of filter/select

bnames = read.csv("data/bnames.csv.bz2", stringsAsFactors = FALSE) 
births = read.csv("data/births.csv",     stringsAsFactors = FALSE)


# Slide 30/1
# Mini Assignment -- do this in base R and dplyr: 

# **Find all of the names that are in the same soundex as the name “Vivian”. 
# **Find all of the girls (subset) born in 1900 or 2000.
# How many times did a name reach a prop greater than 0.01 after the year 2000?

bnames$soundex[bnames$name=="Vivian"][1]

table(bnames$name[bnames$soundex=="V150"])
unique(bnames$name[bnames$soundex=="V150"]) # vector output
table(bnames$name[bnames$soundex==bnames$soundex[bnames$name=="Vivian"][1]]) # combined


# Slide 37
select(tbl, -color)
tbl1 <- as.data.frame(tbl)
tbl1[, -1] # what happened her with the standard method?
tbl1[, -1,  drop = FALSE] # class preservation method for 1x column data.frame

# 39: Compound select statements
select(mtcars, starts_with(c("m")), starts_with("c"))

# Regex:
select(mtcars, matches("^c|^m"))

# MINI ASSIGNMENT: Slide 40: Perform this in base R as well.


# SLide 45
df1 = data.frame(color = c(4,1,5,3,2), value = 1:5)
arrange(df1, color)

df_order     <- order(df1$color) # Returns the indices for ascending order.
df_order_neg <- order(df1$color, decreasing=TRUE) # Returns the indices for ascending order.

# What's happening here?
df1[df_order, ]
df1[df_order_neg, ]

# and here?
df1[df_order, 1] # again, coercion
df1[df_order, 1, drop=FALSE] # how to avoid coercion


# Slide 48 (Code change: must specify range)
arrange(bnames, desc(prop))[1:3, ]


arrange(filter(bnames, name == "Vivian"), desc(prop))[1,]

# Slide 59: Mini Assignment #1 

# With th the vivian data frame:
# a. Add a new column to the data that changes the prop to a percentage.
# b. Create a summary that displays the min, mean, and max prop Vivian’s name.



# Another strategy: magrittr:
# We will discuss the magrittr again at the end of the lecture, but the 
# challenge of reading the code directly above is to some extent 
# mitigated with the use of the %>% pipe operation.


# Using magrittr
vyear <- filter(bnames, name == "Vivian") %>% 
	arrange(., desc(prop)) %>%
	select(., year) %>%
	summarize(., first(year)) # or summarise, same thing (you will see examples of both on the net)

cat("The most popular Vivian year was ", as.numeric(vyear), ".", sep="")

# #----------------------------------#

# Mini assignment 2: in pairs, describe the two approaches below in plain english 
# and venture a guess about what the output represents.
# (hint: for method 1 work inside-out, as you would with SQL).

# Method 1: SQL-ish
# install.packages("nycflights13")
library(nycflights13)

flights$date <- as.Date(x=paste(flights$year, flights$month, flights$day, sep="-"))

hourly_delay <- filter( 
	summarise(
		group_by( # Groups the operation by a particular (factor-like) variable
			filter(
				flights, 
				!is.na(dep_delay)
			), 
			date, hour
		), 
		delay = mean(dep_delay), 
		n = n()
	), 
	n > 10 
) 


# Method 2: magrittr-ish
hourly_delay2 <- flights %>% 
	filter(!is.na(dep_delay)) %>% 
	group_by(date, hour) %>% 
	summarise( 
		delay = mean(dep_delay), 
		n = n() ) %>% 
	filter(n > 10)

# What could we add to the output above?

class(hourly_delay2)

group_by(ungroup(hourly_delay2), date) %>%
	summarize(., `Average Delay`= paste0(round(mean(delay), digits=1), "hours")) %>%
	arrange(., desc(mean)) %>%
	slice(., 1:10)

#----------------------------------#




# Slide 68

x = data.frame(
  name = c("John", "Paul", "George", "Ringo", "Stuart", "Pete"), 
  instrument = c("guitar", "bass", "guitar", "drums", "bass","drums")) 

y = data.frame(name = c("John", "Paul", "George", "Ringo", "Brian"), 
               band = c("TRUE", "TRUE", "TRUE", "TRUE", "FALSE"))

left_join(x, y, by = "name") #To which column is the error referring?

# Quiz: How to fix?

x = tibble(
  name = c("John", "Paul", "George", "Ringo", "Stuart", "Pete"), 
  instrument = c("guitar", "bass", "guitar", "drums", "bass","drums")) 

y = tibble(name = c("John", "Paul", "George", "Ringo", "Brian"), 
               band = c("TRUE", "TRUE", "TRUE", "TRUE", "FALSE"))

left_join(x, y, by = "name") 
inner_join(x, y, by = "name")
semi_join(x, y, by = "name")


# Doubling a non-match in y
y = tibble(name = c("John", "Paul", "George", "Ringo", "Brian", "Brian"), 
		   band = c("TRUE", "TRUE", "TRUE", "TRUE", "FALSE", "FALSE"))

left_join(x, y, by = "name") 
inner_join(x, y, by = "name")
semi_join(x, y, by = "name")


# Two matches in y
y = tibble(name = c("John", "Paul", "George", "Ringo", "Ringo", "Brian"), 
           band = c("TRUE", "TRUE", "TRUE", "TRUE", "FALSE", "TRUE"))

inner_join(x, y, by = "name")
semi_join(x, y, by = "name")

merge(x, y) # Base R behavior
merge(x, y, all.x=TRUE)

# Slide 75
bnames2 = left_join(bnames, births, by = c("year","sex")) 
bnames2

# Slide 76

bnames2 = mutate(bnames2, n = round(prop * births))

# Quiz: explore the data and determine how we know whether proportion corresponds 
# to ALL births or just births by gender?

# Slide 76 Check proportions
out <- bnames[bnames$year==1990 & bnames$sex=="boy", ]
sum(out$prop)

out <- bnames[bnames$year==1990, ]
sum(out$prop)

# Slide 77-86: intro to group by

head(births)

# Slide 86
totals <- group_by(bnames2, name) %>%
  summarise(., total = sum(n)) 
head(totals)

# Show this on Slide 89
totals <- group_by(bnames2, name, sex) %>%
  summarise(., total = sum(n)) 
head(totals)

# Slide 90

by_name_sex = group_by(bnames2, name, sex) 
ungroup(by_name_sex) # Not save until it's assigned to an object

# Slide 92

# magrittr (could be simplified but this is more readable)
stotals <- group_by(bnames2, soundex) %>%
  summarise(., total = sum(n)) %>%
  arrange(., desc(total)) %>%
  slice(., 1L) %>% # What's this? (explicit integer)
  select(., soundex) %>%
  inner_join(bnames, .) %>%
  select(., name) %>%
  group_by(., name) %>%
  summarize(., total=n())

#-------------------------#
# Brief aside:
x <- 1:100
typeof(x) # integer
y <- x+1
typeof(y) # double, twice the memory size
object.size(y)
z <- x+1L
typeof(z) # still integer
object.size(z) # 440 bytes 

options(scipen=8)
2e9L 
2e9L * 4L # no go
#-------------------------#
# Slide 95
year_sex = group_by(bnames2, year, sex) 
ytotals = summarise(year_sex, births = sum(n)) 
ytotals

# Slide 96
year_sex = group_by(bnames2, year, sex)
ranks = mutate(year_sex, rank = rank(desc(prop))) 
ranks

# Slide 97

ones <- filter(ranks, rank == 1) %>%
  select(., year, name, sex)

table(ones$name)

# Examine the raw data
# Mike Doughty: 27 Jennifers

#   https://www.youtube.com/watch?v=1nN_5kkYR6k

# Slide 98

arrange(summarise(group_by(ones, name), count = n()), desc(count))

# Slide 99
?`%>%`

# Slide 101/102 Summarize
bnames3 = select(bnames2,-soundex) #Dropping the soundex column. 
name_sex = group_by(bnames3, name, sex)
name_sex

bnames3 = select(bnames2,-soundex)
name_sex = group_by(bnames3, name, sex)
summary1 = summarise(name_sex, total = sum(n)) 
summary1 #Summarises first by going across the sex group.

# Further resources
# See the dplyr vingette:
# https://cran.rstudio.com/web/packages/dplyr/vignettes/introduction.html


by_tailnum <- group_by(flights, tailnum)
delay <- summarise(by_tailnum,
                   count = n(),
                   dist = mean(distance, na.rm = TRUE),
                   delay = mean(arr_delay, na.rm = TRUE))
delay <- filter(delay, count > 20, dist < 2000)

# Interestingly, the average delay is only slightly related to the
# average distance flown by a plane.
ggplot(delay, aes(dist, delay)) +
  geom_point(aes(size = count), alpha = 1/2) +
  geom_smooth() +
  scale_size_area()

