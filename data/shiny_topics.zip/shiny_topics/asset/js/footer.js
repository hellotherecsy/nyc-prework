<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>
(function () {
  $('.remark-slide-content').prepend('<div class="nyc-header" />');
})();
</script>
