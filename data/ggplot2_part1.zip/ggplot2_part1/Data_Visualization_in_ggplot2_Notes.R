
library(ggplot2)
rm(list=ls())

# GGPlot is an implementation of Leland Wilkinson's Grammar of Graphics — a 
# general scheme for data visualization which breaks up graphs into semantic 
# components such as scales and layers. (Wikipedia)

# Extensions to GGPlot also allow for the creation of plots which build upon
# Edward Tufte's data visualization fundamentals. See, e.g.:
# https://www.edwardtufte.com/tufte/posters


# Napoleon's march translation
https://en.wikipedia.org/wiki/Charles_Joseph_Minard#/media/File:Minard.png
# Figurative Map of the successive losses in men of the French Army in the Russian campaign 1812-1813.

# Drawn by Mr. Minard, Inspector General of Bridges and Roads in retirement. 
# Paris, 20 November 1869.
# The numbers of men present are represented by the widths of the colored zones 
# in a rate of one millimeter for ten thousand men; these are also written beside 
# the zones. Red designates men moving into Russia, black those on retreat. — The 
# informations used for drawing the map were taken from the works of Messrs. Chiers, 
# de Ségur, de Fezensac, de Chambray and the unpublished diary of Jacob, pharmacist 
# of the Army since 28 October.
# In order to facilitate the judgement of the eye regarding the diminution of the 
# army, I supposed that the troops under Prince Jèrôme and under Marshal Davoust, 
# who were sent to Minsk and Mobilow and who rejoined near Orscha and Witebsk, 
# had always marched with the army.

# Slide 31/2
g <- ggplot(data = mpg, aes(x = displ, y = hwy)) # Canvas is made
g +  geom_point() + geom_smooth(method = "lm") # Define how the canvas is drawn

?mtcars

# Notes on smoothing method defaults
# smoothing method (function) to use, eg. lm, glm, gam, loess, rlm. 
# For datasets with n < 1000 default is loess. For datasets with 1000 or
# more observations defaults to gam, see gam for more details.

g <- ggplot(data = mpg, aes(x = displ, y = hwy)) # Canvas is made
g +  geom_point() + geom_smooth(method = "loess")

# From the loess package on methods: Local Polynomial Regression Fitting
# loess: Fitting is done locally. That is, for the fit at point x, the fit is made 
# using points in a neighbourhood of x, weighted by their distance from x.

cars.lo <- loess(dist ~ speed, cars)
predict(cars.lo, data.frame(speed = seq(5, 30, 1)), se = TRUE)


# Slide 32: Move to assignment 1, line types
#*#*#*#*#*# BEGIN ASSIGNMENT 1 HERE #*#*#*#*#*# 


# Slide 36: Interpret the warning messages
g <- ggplot(data = mpg, aes(x = displ, y = hwy)) # Canvas is made
g + geom_point() + geom_smooth(method = "lm")
g + geom_point(aes(color = class))
g + geom_point(aes(size = class)) # Categories are not meaningfully ascending
g + geom_point(aes(shape = class))
g + geom_point(aes(alpha = class)) # "Varying alpha is useful for large datasets"

# What happens with more than one aesthetic? 
# It let's you do it, but results will vary and depend on the nature of the
# grouping variable (discrete or continuous, number of discrete categories, etc.)
g + geom_point(aes(alpha = class, color=class)) 
g + geom_point(aes(alpha = class, color=class, shape=class)) 
g + geom_point(aes(alpha = class, color=class, shape=class, size=class)) 


# Alpha examples for slide 36 using the diamond dataset
d <- ggplot(diamonds, aes(carat, price))
d + geom_point(alpha = 1/10)
d + geom_point(alpha = 1/20)
d + geom_point(alpha = 1/100)


# Slide 37
g + geom_point(aes(color = class))

# Slide 42: Interpret each of these slides. What do they mean, what relationship is suggested?

# Notice how switching the facet formula shifts grouping to x or y
g + geom_point() + facet_grid(. ~ cyl) # Relationship b/w mpg and displacement by cyl count
g + geom_point() + facet_grid(cyl ~ .) # Relationship b/w mpg and displacement by cyl count
g + geom_point() + facet_wrap("cyl") # needs quotes when not in formula for SE to work properly

g + geom_point() + facet_grid(drv ~ .) # Relationship b/w mpg and displacement by front/rear/4-wheel drive
g + geom_point() + facet_grid(drv ~ cyl) # Relationship b/w mpg and displacement drive type and cyl
g + geom_point() + facet_wrap( ~ class) # Relationship b/w mpg and displacement drive type by vehicle class


#*#*#*#*#*# BEGIN ASSIGNMENT 2 HERE #*#*#*#*#*# 

# Side 44
g <- ggplot(data = mpg, aes(x = displ, y = hwy)) 


# Slide 44/5
g + geom_point()

# Slide 46
g + geom_smooth()

?geom_smooth

# Slide 47: overlay multiple geoms
g + geom_point() + geom_smooth(se = FALSE)



# Slide 47 # How do we make a box plot?

ggplot(data = mpg, aes(x = class, y = hwy)) + geom_point()

ggplot(data = mpg, aes(x = class, y = hwy)) + geom_jitter() # Jitter the points


# Slide 48
g <- ggplot(data = mpg, aes(x = class, y = hwy))

g + geom_boxplot()

# What could be improved here? (continues with next code snippet)
ggplot(data = mpg, aes(x = class, y = hwy)) + geom_boxplot()


# Slide 58
g <- ggplot(data = mpg, aes(x = reorder(class, hwy), y = hwy)) + geom_boxplot()
g + geom_boxplot()

# Slide 59: assignment, reorder the class by median rather than default
ggplot(data = mpg, aes(x = reorder(class, hwy, median), y = hwy)) + geom_boxplot()


# Slide 62: Help Documents Online, Review Geoms

#*#*#*#*#*# BEGIN ASSIGNMENT 3 HERE #*#*#*#*#*# 

# At slide 62, transition to group assignment 3: Economic Time series.

#*#*#*#*#*#     END ASSIGNMENT 3    #*#*#*#*#*# 


## Begin diamond data set, slide #62

ds <- diamonds

# Mini assignment: Calculate table-width using the diagram on slide 65


ds$w <- ds$table/100 # Convert to proportion
ds$twid <- ds$x * ds$w # Scale the total width
ds$twidc <- ds$x * (ds$table / 100) # Or calculate in one line
all.equal(ds$twid, ds$twidc)
ds$w <- ds$twidc <- NULL

# Bar charts
ggplot(data = diamonds, aes(x = cut)) + geom_bar(aes(fill = cut)) 

# With brewer pal
ggplot(data = diamonds, aes(x = cut)) + geom_bar(aes(fill = cut)) +
  scale_fill_brewer(palette="Spectral")

# Manually
ggplot(data = diamonds, aes(x = cut)) + geom_bar(aes(fill = cut)) +
  scale_fill_manual(values = c("black", "grey80", "yellow", "#1BA938", "green"))

# What happened here?
ggplot(data = diamonds, aes(x =cut)) + geom_bar(aes(color = cut))


#*#*#*#*#*# BEGIN ASSIGNMENT 4 HERE #*#*#*#*#*# 

# Slide 72-4 Position adjustments

# Very common type of corporate chart
ggplot(data = diamonds, aes(x = color)) +
  geom_bar(aes(fill = cut), position = "dodge")

# Can you name some examples from your own work?

# Slide 76: Jittering a scatter plot

ggplot(data = mpg, aes(x = cty, y = hwy)) +
  geom_point(position = "jitter")

#*#*#*#*#*# BEGIN ASSIGNMENT 5 HERE #*#*#*#*#*# 
# Jitter plot of diamonds with specific carat size



#()# Continue with Histograms, Slide 79

g <-ggplot(data = diamonds, aes(x = carat))
g + geom_histogram(binwidth =  1)
g + geom_histogram(binwidth = .1)


# Slide 88
# Mini assignment: Using the definition on this slide, manually calculate the 
# default statbin parameter of this histogram for the carat variable.



binsrange <- (range(diamonds$carat)[2] - range(diamonds$carat)[1]) / 30
g + geom_histogram(binwidth = binsrange)
g + geom_histogram()

g <- ggplot(data = diamonds, aes(x = depth))
g + geom_histogram(binwidth = 0.2)

zoom <- coord_cartesian(xlim = c(55, 70)) # What's zoom doing here?
g + geom_histogram(binwidth = 0.2) + zoom

g + geom_histogram(aes(fill = cut), binwidth = 0.2) + zoom

# Slide 99

ggplot(data = diamonds, aes(x = price)) +
  geom_histogram(binwidth = 500) + facet_wrap(~ cut)


ggplot(data = diamonds, aes(x = price)) + geom_density(aes(color = cut)) +
  scale_y_continuous(labels=scales::comma)

ggplot(data = diamonds[diamonds$color!="F", ], aes(x = price)) + geom_density(aes(color = color)) +
  scale_y_sqrt()

# Scale inverts with log transformation
ggplot(data = diamonds[diamonds$color!="F", ], aes(x = price)) + geom_density(aes(fill = color)) +
  scale_y_log10(labels=comma)


# Slide 102: Mini Assignment: How could you standardize the price by cut?
# Make a standardized variable and take only those diamonds in the -1 - 1 zscore range.

dt <- diamonds
dt$Price <- ave(dt$price, dt$cut, FUN=scale)

dtn <- dt[dt$Price<.5 & dt$Price>-.5, ]

ggplot(data = dtn, aes(x = Price)) + geom_density(aes(color= cut))

ggplot(data = dtn, aes(x = Price)) + 
  geom_density(aes(color= cut)) + 
  facet_wrap( ~ cut)


# Slide 107: Visualizing Big Data

g <- ggplot(data = diamonds, aes(x = carat, y = price))
g + geom_point(aes(color = cut))
g + geom_bin2d()
g + geom_density2d()
g + geom_point() + geom_density2d()

g + geom_smooth()
g + geom_smooth(aes(group = cut)) # How would you add a legend?
g + geom_smooth(aes(color = cut)) # Smooshed lines
g + geom_smooth(aes(color = cut)) + facet_wrap(~cut) # How's this?

# Do it again but drop ideal to make it look even
g + geom_point(size = 0.5, alpha = 0.1)



# Other Options
# Plotly
install.packages("plotly")
library(plotly)

# Sample b/c it's slower
d <- diamonds[sample(nrow(diamonds), 1000), ]
plot_ly(d, x = ~carat, y = ~price, color = ~carat)


# Or merge ggplot and plot_ly
p <- ggplot(data = d, aes(x = carat, y = price)) +
  geom_point(aes(text = paste("Clarity:", clarity))) +
  geom_smooth(aes(colour = cut, fill = cut)) + facet_wrap(~ cut)

ggplotly(p) # Some formatting issues


ggsave("my-plot.pdf")

# Note: Cairo is good for windows
install.packages("Cairo")



# Final Assignment: Plot yourself
install.packages("placement")
install.packages("leaflet")
devtools::install_github("DerekYves/dsademo")

install.packages("maps")

library(placement)
library(RCurl)
library(jsonlite)
library(ggplot2)
library(leaflet)
library(sp)
library(dsademo)
library(maps)

# Set your addresses

x <- c("3203 SE Woodstock Blvd, Portland, OR", # In college
       "University Ave, Fairbanks, AK",  # In the Tundra
       "Main St, Cold Spring, NY",       # In the woods
       "Nelson Ave, Redondo Beack, CA")  # Small



places <- lapply(x, URLencode)
baseurl <- baseurlfunc()
places2code <- paste0(baseurl, places)
returns <- lapply(places2code, getURL)
thedata <- lapply(returns, fromJSON)
coords <- t(sapply(thedata, function(x) unlist(x$results$geometry$location)))
testaddress <- fromJSON(getURL(places2code[1]))

mp <- NULL
world <- borders("world", colour="gray50", fill="gray50", xlim = c(-170, -100), ylim = c(20, 70))
mp <- ggplot() +  world + coord_equal() + theme_void() + ggtitle("The Places I've Been")
mp <- mp+ geom_point(aes(x=coords[ , 2], y=coords[,1]) ,color="green", size=3) 



# Let's calculate distance to Starbucks. Who is the closest on average?
# Give each one a name
college <- coords[1, ]
alaska  <- coords[2, ]
woods   <- coords[3,]
small   <- coords[4,]

how_far <- (coffeetime(college) + 
              coffeetime(alaska) +
              coffeetime(woods) + 
              coffeetime(small)  ) / 4 *.62 

cat("The mean distance is:", round(how_far, digits=1), "miles.")
if(how_far<5) message("You seem to like Starbucks!")


coordsdf <- as.data.frame(coords)
coordsdf$place <- c("college", "alaska", "woods", "small") 
                    

leaflet(data = coordsdf) %>% addTiles() %>%
  addMarkers(~lng, ~lat, popup = ~as.character(place))


