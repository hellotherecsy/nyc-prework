#######################################
# Mini assignment: Calculate table-width using the diagram on slide 65

#######################################
# Slide 88
# Mini assignment: Using the definition on this slide, manually calculate the 
# default statbin parameter of this histogram for the carat variable.

#######################################
# Slide 102: Mini Assignment: How could you standardize the price by cut?
# Make a standardized variable and take only those diamonds in the -1 - 1 zscore range.

#######################################
